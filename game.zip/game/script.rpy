# The script of the game goes in this file.

# Declare characters used by this game. The color argument colorizes the
# name of the character.

#character

default player_name = "Me"

define me = Character("[player_name]", color="#ffffff", image="me")
define spd = Character('Sleep paralysis demon', color='#ff0000', who_font="fonts/PixelMplus12.ttf", what_font="fonts/PixelMplus12.ttf")
define head = Character('The head', color='#d000ff', who_font="fonts/VT323-Regular.ttf", what_font="fonts/VT323-Regular.ttf")
define police = Character('An officer', color='#ffea00')
define mysterious = Character('A mysterious man', color='#ffea00')
define mysterious1 = Character('The first mysterious man', color='#ffea00')
define mysterious2 = Character('The second mysterious man', color='#ffea00')
define mrs = Character('Mrs.', color='#e20000',image="mrs", who_font="fonts/PixelMplus12.ttf", what_font="fonts/PixelMplus12.ttf")
define lady = Character('A mysterious lady', color='#e20000', who_font="fonts/PixelMplus12.ttf", what_font="fonts/PixelMplus12.ttf")

#Variables1
#persistent
default persistent.ending1 = False
default persistent.ending2 = False
default persistent.ending3 = False
default persistent.ending4 = False
default persistent.ending5 = False
default persistent.ending6 = False
default persistent.ending7 = False
default persistent.ending8 = False
default persistent.ending9 = False
default persistent.ending10 = False

default persistent.achievement1 = False
default persistent.achievement2 = False
default persistent.achievement3 = False
default persistent .achievement3_notify = False
default persistent.achievement4 = False
default persistent.get_caught = False

#variable click, score, pizza
default searching = False
default bedroom_clicked = False
default kitchen_clicked = False
default mirror_clicked = False
default score = 0
default click_goal = 4
default trash_bedroom_clicked = False
default trash_living_clicked = False
default trash_kitchen_clicked1 = False
default trash_kitchen_clicked2 = False
default throw_out_trash = False
default minute = 0
default hour = 0
default misclick = 0
default pizza5_clicked = False
default pizza4_clicked = False
default pizza3_clicked = False
default pizza2_clicked = False
default pizza1_clicked = False
default pizza = 0
default beforebed = True
default web_clicked = False
default puddle_clicked = False
default knife_recieved = False
default bar_clicked = False
default sleep_paralysis_web_clicked = False
default spd1_clicked = False

default drag_count = 0

default look_left = False
default look_center = False
default look_right = False

default name = False

play music 'audio/.mp3' volume 0.03
play sound 'audio/.mp3' volume 0.03

init python:
    def adjust_attempt(amount):
        global attempt
        attempt = max(0, min(attempt + amount, max_attempt))

    def show_attempt_status():
        renpy.show_screen("attempt_status")

    config.overlay_functions.append(show_attempt_status)

#looking logic

init python:
    def set_center(trans, st, at):
        store.look_left = False
        store.look_center = True
        store.look_right = False
        return None  

    def set_left(trans, st, at):
        store.look_left = True
        store.look_center = False
        store.look_right = False
        return None

    def set_right(trans, st, at):
        store.look_left = False
        store.look_center = False
        store.look_right = True
        return None






init python:
    def hand_dragged(drags, drop):
        if not drop:
            return 
        return drop.drag_name



init python:
    def eye_dragged(drags, drop):
        if not drop:
            return 
        return drop.drag_name

init python:
    def stretch_dragged(drags, drop):
        if not drop:
            return
        if drags[0].drag_name == "arm" and drop.drag_name == "target_arm":
            return "arm_finished"    
        if drags[0].drag_name == "leg" and drop.drag_name == "target_leg":
            return "leg_finished"

#Null
image me accept = Null()
image me angry = Null()
image me anxiety= Null()
image me anxiety 1= Null()
image me anxiety 2= Null()
image me blank = Null()
image me close_eyes = Null()
image me dizzy = Null()
image me got_it = Null()
image me idle = Null()
image me scared = Null()
image me serious = Null()
image me shock = Null()
image me side_eyes = Null()
image me sigh = Null()
image me smirk = Null()
image me stunned = Null()
image me talk = Null()
image me well = Null()
image me what = Null()




#transform
transform fade_in_bg:
    alpha 0.0
    ease 0.5 alpha 1.0
transform zoomin50:
    anchor (0.5, 0.5)
    pos (0.5, 0.5)
    zoom 0.5      
    linear 0.1 zoom 1.0  
transform zoomin100:
    anchor (0.5, 0.5)
    pos (0.5, 0.5)
    zoom 0.0          
    linear 0.1 zoom 1.0  
transform zoomin200:
    anchor (0.5, 0.5)
    pos (0.5, 0.5)
    zoom 0.0          
    linear 0.1 zoom 2.0  

transform zoomout300:
    anchor (0.5, 0.5)
    pos (0.5, 0.5)
    alpha 0.0
    zoom 3.0
    easeout 0.3 alpha 1.0 zoom 1.0

transform moveinbuttom:
    anchor (0.5, 0.5)
    pos (0.5, 1.5)
    linear 1.0 ypos 0.5 
    
transform lower:

    anchor (0.5, 1.0)
    pos (0.5, 1.0)

transform upper:

    anchor (0.5, 0.0)
    pos (0.5, 0.0)

transform movetoupper:

    anchor (0.5, 1.0)
    pos (0.5, 1.0)
    
    
    linear 5.0 anchor (0.5, 0.0) pos (0.5, 0.0)
    


#image

image side me anxiety:
    "side me anxiety 1" with Dissolve(0.5, alpha=True)
    pause 0.5
    "side me anxiety 2" with Dissolve(0.5, alpha=True)
    pause 0.5
    repeat

image button_hover:
    "button_hover1.png" with Dissolve(0.5, alpha=True)
    pause 0.5
    "button_hover2.png" with Dissolve(0.5, alpha=True)
    pause 0.5
    "button_hover3.png" with Dissolve(0.5, alpha=True)
    pause 1.0
    repeat

image bg found_corpse:
    subpixel True

    contains:
       
        zoom 1.02 

        parallel:
            xoffset 0
            linear 3.0 xoffset -10
            linear 3.0 xoffset 0
            repeat
        parallel:
            "bg found_corpse 1" 
            pause 7.0
            "bg found_corpse 2" 
            pause 0.2
            "bg found_corpse 1" 
            pause 3.0
            "bg found_corpse 2" 
            pause 0.3
            repeat
    

image spd grabbed:
    "spd grabbed 1.png" with Dissolve(0.5, alpha=True)
    pause 1.0
    "spd grabbed 2.png" with Dissolve(0.5, alpha=True)
    pause 1.0
    "spd grabbed 3.png" with Dissolve(0.5, alpha=True)
    pause 1.0
    repeat

image bg dream bedroom:
    "bg dream bedroom 1" with Dissolve(0.5, alpha=True)
    pause 1.0
    "bg dream bedroom 2" with Dissolve(0.5, alpha=True)
    pause 1.0
    "bg dream bedroom 3" with Dissolve(0.5, alpha=True)
    pause 1.0
    repeat

image spd stabbed2:
    subpixel True
    "spd stabbed2 1" with Dissolve(0.5, alpha=True)
    xoffset 0 yoffset 0
    linear 0.5 xoffset 5
    pause 1.0
    "spd stabbed2 2" with Dissolve(0.3, alpha=True)
    xoffset 0 yoffset 0
    linear 0.5 yoffset 5
    
    "spd stabbed2 3" with Dissolve(0.3, alpha=True)
    xoffset 0 yoffset 0
    linear 0.5 yoffset 5
    "spd stabbed2 2" with Dissolve(0.3, alpha=True)
    pause 0.3
    repeat

image spd pin idle:
    "spd pin idle 1" with Dissolve(0.5, alpha=True)
    pause 3.0
    "spd pin idle 2" with Dissolve(0.5, alpha=True)
    pause 0.4
    "spd pin idle 3" with Dissolve(0.5, alpha=True)
    pause 0.8
    "spd pin idle 2" with Dissolve(0.5, alpha=True)
    pause 0.2
    repeat

image spd_hand knife_move:
    subpixel True
    "spd_hand knife"
    yoffset 0
    pause 3.0
    linear 1.2 yoffset 15
    linear 0.7 yoffset 0
    
    repeat

image bg look:
    "bg look 1.png" with Dissolve(0.2, alpha=True)
    pause 0.5
    "bg look 2.png" with Dissolve(0.2, alpha=True)
    pause 0.5
    "bg look 3.png" with Dissolve(0.2, alpha=True)
    pause 0.5
    repeat

image knife:
    subpixel True
    yoffset 0

    
    align (0.5, 0.5)      
    zoom 1.5 
    "idle knife" with Dissolve(0.5, alpha=True)     
    pause 0.2
    linear 1.2 yoffset 15
    linear 0.7 yoffset 0
    "hover knife" with Dissolve(0.5, alpha=True)
    pause 0.2
    
    linear 1.2 yoffset 15
    linear 0.7 yoffset 0
    repeat


image spd full top:
    "spd full top 1" with Dissolve(0.5, alpha=True)
    pause 1.0
    "spd full top 2" with Dissolve(0.5, alpha=True)
    pause 1.0
    "spd full top 3" with Dissolve(0.5, alpha=True)
    pause 1.0
    repeat

image spd idle:
    "spd idle 1" with Dissolve(0.5, alpha=True)
    pause 4.0
    "spd idle 2" with Dissolve(0.5, alpha=True)
    pause 0.5
    "spd idle 3" with Dissolve(0.5, alpha=True)
    pause 0.5
    repeat

image screen phone:
    "screen phone 1" with Dissolve(0.5, alpha=True)
    pause 1.0
    "screen phone 2" with Dissolve(0.5, alpha=True)
    pause 0.5
    repeat

image spd head_talk:
    "spd head_talk 1" 
    pause 0.5
    "spd head_talk 2" 
    pause 0.5
    repeat

image spd embarrassed head:
    "spd embarrassed head 1" 
    pause 0.5
    "spd embarrassed head 2" 
    pause 0.5
    repeat

image spd pin talk:
    "spd pin talk 1" 
    pause 0.5
    "spd pin talk 2" 
    pause 0.5
    repeat

image spd laugh:
    "spd laugh1" 
    xoffset 0 yoffset 0
    linear 0.5 yoffset 5
    "spd laugh2" 
    xoffset 0 yoffset 0
    linear 0.5 yoffset 5
    repeat

image hover door:
    "hover door 1.png" 
    pause 0.5
    "hover door 2.png" 
    pause 0.5
    "hover door 3.png" 
    pause 1.0
    repeat

image spd with_phone1:
    "spd with_phone1 left" with Dissolve(0.5, alpha=True) 
    pause 1.0
    "spd with_phone1 center" with Dissolve(0.5, alpha=True) 
    pause 1.0
    "spd with_phone1 right" with Dissolve(0.5, alpha=True) 
    pause 1.0
    "spd with_phone1 center" with Dissolve(0.5, alpha=True) 
    pause 1.0
    repeat

image bg relax:
    "bg relax 1.png" with Dissolve(0.5, alpha=True)
    pause 1
    "bg relax 2.png" with Dissolve(0.5, alpha=True)
    pause 1
    "bg relax 3.png" with Dissolve(0.5, alpha=True)
    pause 1
    repeat

image hover bar:
    "search bar 2.png" 
    pause 0.75
    "search bar 1.png" 
    pause 0.75
    repeat

image bg com load:
    "bg com 1" 
    pause 0.5
    "bg com 2" 
    pause 0.5
    "bg com 3" 
    pause 0.5
    "bg com 4" 
    pause 0.5
    repeat


image bg tv:
    "bg tv 1.png" 
    pause 0.5
    "bg tv 2.png" 
    pause 0.5
    repeat

image hover grab:
    "hover grab 1.png" 
    pause 0.5
    "hover grab 2" 
    pause 0.5
    "hover grab 3" 
    pause 0.5
    repeat

image bg window eye:
    "bg window eye 1" with Dissolve(0.5, alpha=True)
    pause 0.75
    "bg window eye 2" with Dissolve(0.5, alpha=True)
    pause 0.75
    "bg window eye 3" with Dissolve(0.5, alpha=True)
    pause 0.75
    "bg window eye 4" with Dissolve(0.5, alpha=True)
    pause 0.75
    
    repeat

image bg memory:
    "bg memory1.png" with Dissolve(0.5, alpha=True)
    pause 1
    "bg memory2.png" with Dissolve(0.5, alpha=True)
    pause 1
    "bg memory3.png" with Dissolve(0.5, alpha=True)
    pause 1
    repeat

image bg dizzy:
    "bg dizzy 1.png" with Dissolve(0.5, alpha=True)
    pause 1
    "bg dizzy 2.png" with Dissolve(0.5, alpha=True)
    pause 1
    "bg dizzy 3.png" with Dissolve(0.5, alpha=True)
    pause 1
    repeat

#looking image
image spd full stand:
    
    "spd full stand right" with Dissolve(0.2, alpha=True)
    function set_right
    pause 2.0

    "spd full stand center" with Dissolve(0.2, alpha=True)
    function set_center
    pause 2.0
    
    "spd full stand left" with Dissolve(0.2, alpha=True)
    function set_left
    pause 2.0
    
    "spd full stand center" with Dissolve(0.2, alpha=True)
    function set_center
    pause 2.0
    
    repeat

image spd full bend:
    
    
    "spd full bend left" with Dissolve(0.5, alpha=True)
    function set_left
    pause 1.7
    
    "spd full bend center" with Dissolve(0.5, alpha=True)
    function set_center
    pause 1.7
    
    "spd full bend right" with Dissolve(0.5, alpha=True)
    function set_right
    pause 1.7

    "spd full bend center" with Dissolve(0.5, alpha=True)
    function set_center
    pause 1.7
    
    repeat

image spd full lay:
    "spd full lay center" with Dissolve(0.5, alpha=True)
    function set_center
    pause 1.5
    
    "spd full lay left" with Dissolve(0.4, alpha=True)
    function set_left
    pause 1.5
    
    "spd full lay center" with Dissolve(0.4, alpha=True)
    function set_center
    pause 1.5
    
    "spd full lay right" with Dissolve(0.5, alpha=True)
    function set_right
    pause 1.5
    
    repeat

image spd catch 1:
    subpixel True
    
    contains:
        "spd catch1 bg"
        zoom 1.5
        xoffset -10
        linear 3.0 xoffset 0
        linear 3.0 xoffset -10
        repeat

    contains:
        "spd catch1 top"
    
        xoffset 0
        matrixcolor IdentityMatrix()
        
        parallel:
            linear 3.0 xoffset -20
            linear 3.0 xoffset 0
            repeat
        parallel:
            linear 3.0 matrixcolor BrightnessMatrix(-0.2)
            linear 3.0 matrixcolor BrightnessMatrix(0.0)
            repeat


image bg gross:
    subpixel True
    
    contains:
        "bg gross bg"
        zoom 1.05
        xoffset 0 yoffset 0
        ease 2.0 xoffset 10 yoffset 5
        ease 2.0 xoffset 0 yoffset 0
        repeat

    contains:
        "bg gross frame"
        zoom 1.15
        xoffset 0 yoffset 0
        
        parallel:
            ease 2.0 xoffset -30 yoffset -10
            ease 2.0 xoffset 0 yoffset 0
            repeat
        
        parallel:
            ease 2.0 zoom 1.18
            ease 2.0 zoom 1.15
            repeat



image spd catch 2:
    subpixel True

    contains:
        "spd catch2 bg"

        zoom 1.5
        
        parallel:
            xoffset -10
            linear 3.0 xoffset 0
            linear 3.0 xoffset -10
            repeat

        parallel:

            linear 1.0 matrixcolor BrightnessMatrix(0.0) * IdentityMatrix()
            linear 1.0 matrixcolor BrightnessMatrix(-0.3) * TintMatrix("#FFBBBB")
            linear 1.0 matrixcolor BrightnessMatrix(0.0) * IdentityMatrix()
            repeat


    contains:
        contains:

            "spd catch2 top 1" with Dissolve(0.5, alpha=True)
            pause 1.0
            "spd catch2 top 2" with Dissolve(0.5, alpha=True)
            pause 1.0
            repeat


        parallel:
            xoffset 0
            linear 3.0 xoffset -20
            linear 3.0 xoffset 0
            repeat

    contains:
        "tongue"
        zoom 1
        xoffset 0
        linear 3.0 xoffset -10
        linear 3.0 xoffset 0
        repeat

image run:
    subpixel True


    contains:
        "street1"
        anchor (0.5, 0.5) pos (0.5, 0.5)
        
        parallel:

            zoom 1.0 
            linear 0.8 zoom 2.0
            repeat

        parallel:
       
            alpha 0.0
            linear 0.2 alpha 1.0
            pause 0.4
            linear 0.2 alpha 0.0
            repeat

    contains:
        "street1"
        anchor (0.5, 0.5) pos (0.5, 0.5)
        
   
        alpha 0.0 
        pause 0.4 
    
        parallel:
        
            zoom 1.0 
            linear 0.8 zoom 2.0
            repeat

        parallel:
            alpha 0.0
            linear 0.2 alpha 1.0
            pause 0.4
            linear 0.2 alpha 0.0
            repeat

    contains:
        zoom 1.2
    
        "black_sky"
        yoffset 0
        linear 0.25 yoffset -10
        linear 0.25 yoffset 0
        repeat

    contains:
        "left_hand"
        yoffset 550
        linear 0.25 yoffset 0
        linear 0.25 yoffset 550
        pause 0.5
        repeat

    contains:
        "right_hand"
        yoffset 550
        pause 0.5
        linear 0.25 yoffset 0
        linear 0.25 yoffset 550
        repeat

    contains:
        "black frame"


# The game starts here.
screen Warning_screen:
    frame:
        xalign 0.5
        yalign 0.5
        xysize (1305, 905)
        background Solid("#a0a0a0") 
        
        frame:
            xalign 0.5
            yalign 0.5
            xysize (1300, 900)
            background Solid("#050505") 
            padding (60, 40)

            vbox:
                xalign 0.5
                yalign 0.5
                spacing 20
                
                text "{b}WARNING" size 45 color "#ff0000" xalign 0.5
                
                null height 20

                text "This game contains flashing images that might trigger seizure for people with photosensitive eplipsy. The game also has loud sound and jump scare." size 24 color "#ffffff" xalign 0.5
                
                
                null height 50
                text "{b}Do you want to continue?." size 24 color "#ffffff" xalign 0.5
                hbox:
                    xalign 0.5
                    spacing 200
                    
                    textbutton "Yes":
                        text_size 40 
                        text_color "#00ff08" 
                        text_hover_color "#ffffff"
                        text_bold True
                        action [Play("sound", "sfx_yes.mp3"), Jump("start0")]
                        
                    textbutton "No":
                        text_size 40 
                        text_color "#ff0000" 
                        text_hover_color "#ffffff"
                        text_bold True
                        action [Play("sound", "sfx_no.mp3"), MainMenu()]


label start:

    call screen Warning_screen

    
label start0:
    scene black
    stop music
    "{b}At your house - Evening."
    scene bg livingroom0 with fade
    show me idle 
    me "Finally, the pizza has arrived."
    show me smirk
    me "Don't blame me if it's going to be messy."
    call screen living_room0
    
screen display_text(displayText=""):
    frame:
        xalign 0.5
        yalign 0.5
        text displayText

screen living_room0:
    add "bg livingroom0" at fade_in_bg
    
    # pizza
    imagebutton:
        xpos 935
        ypos 1096
        xanchor 0.5
        yanchor 1.0
        idle "idle pizza" 
        hover "hover pizza"
        action [Hide("display_text"), Jump("pizza")]
        hovered Show("display_text", displayText="eat all the pizza pieces")
        unhovered Hide("display_text")

label pizza:
    scene bg pizza with fade
    call screen pizza


screen pizza:

    add "bg pizza" at fade_in_bg

    if not pizza5_clicked:
        imagebutton:
            pos (1159, 546) 
            xanchor 0.5
            yanchor 1.0
            idle "idle pizza 5"
            hover "hover pizza 5"
            action [Play("sound", "sfx_eat.mp3"), SetVariable("pizza5_clicked", True), SetVariable("pizza", pizza + 1)]

    if not pizza4_clicked:
        imagebutton:
            pos (972, 556) 
            xanchor 0.5
            yanchor 1.0
            idle "idle pizza 4"
            hover "hover pizza 4"
            action [Play("sound", "sfx_eat.mp3"), SetVariable("pizza4_clicked", True), SetVariable("pizza", pizza + 1)]

    if not pizza3_clicked:
        imagebutton:
            pos (818, 656)
            xanchor 0.5
            yanchor 1.0
            idle "idle pizza 3"
            hover "hover pizza 3"
            action [Play("sound", "sfx_eat.mp3"), SetVariable("pizza3_clicked", True), SetVariable("pizza", pizza + 1)]

    if not pizza2_clicked:
        imagebutton:
            pos (834, 897) 
            xanchor 0.5
            yanchor 1.0
            idle "idle pizza 2"
            hover "hover pizza 2"
            action [Play("sound", "sfx_eat.mp3"), SetVariable("pizza2_clicked", True), SetVariable("pizza", pizza + 1)]

    if not pizza1_clicked:
        imagebutton:
            pos (1045, 972) 
            xanchor 0.5
            yanchor 1.0
            idle "idle pizza 1"
            hover "hover pizza 1"
            action [Play("sound", "sfx_eat.mp3"), SetVariable("pizza1_clicked", True), SetVariable("pizza", pizza + 1)]

    if pizza == 5:
        textbutton "{b}\"You ate all the pizza pieces.\"":
            xanchor 0.5
            yanchor 0.5
            xpos 0.5
            ypos 0.5

            action [Play("sound", "sfx_yes.mp3"), Jump("start1")]


label start1:
    scene bg livingroom with fade
    show me accept
    me "Ah.. that's great."
    show me talk
    me "They always make the best pizza around here."
    show me idle
    me "It's the only pizzaria in the town."
    show me smirk
    me "I mean the taste is still good though and their slices ain't tiny."
    show me serious
    me "Augh-"
    scene bg dizzy with dissolve
    show me dizzy
    play music 'audio/music_confuse2.mp3' volume 0.5 fadein 5 fadeout 0.5
    me "Not.. again.."
    me "Every single time."
    scene bg drug 1 with dissolve
    show me blank
    pause 1.0
    scene bg drug 2 with dissolve
    pause 1.0
    scene bg drug 3 with dissolve
    pause 1.0
    scene black with dissolve
    pause 3.0
    scene bg livingroom with dissolve
    show me smirk
    stop music
    me "Phew... That's close."
    me "Now back to normal."
    show me talk 
    me "Wait."
    show me sigh
    me "*Sigh*.. I have nothing to do anyway."
    show me smirk
    me "I'm so bored. I wish I would be more of an interesting person than someone like this."
    me "It's always the same everydays over and over again."
    show me talk 
    me "No friends, No hobbies."
    me "What should I even do to pass my time?"
    show me stunned 
    me ""
    show me anxiety
    me "Working or finding job is absolutely not though."
    show me idle
    me "Ahem- enough with messing around. I should look around my house first. Maybe I could think of something else."
    pause 1.0
    show me talk 
    me "Also, I shouldn't forget to check myself in the mirror."
    show me blank

    call screen living_room










screen living_room:
    add "bg livingroom" at fade_in_bg

    # TV
    imagebutton:
        pos (930, 715) 
        xanchor 0.5
        yanchor 1.0
        idle "idle tv"
        hover "hover tv"
        action [Hide("display_text"), Jump("TV")]
        hovered Show("display_text", displayText="TV")
        unhovered Hide("display_text")
    
    # news paper
    imagebutton:
        xanchor 0.5
        yanchor 1.0
        pos (738, 1075) 
        idle "idle news"
        hover "hover news"
        action [Hide("display_text"), Jump("news")]
        hovered Show("display_text", displayText="newspaper")
        unhovered Hide("display_text")

    # door
    imagebutton:
        xanchor 0.5
        yanchor 0.5
        xpos 0.16
        ypos 0.6
        idle "idle door"
        hover "hover door"
        action [Hide("display_text"), Jump("door")]
        hovered Show("display_text", displayText="an entrance")
        unhovered Hide("display_text")

    # pictureframe
    imagebutton:
        xanchor 0.5
        yanchor 1.0
        pos (1105, 705) 
        idle "idle frame"
        hover "hover frame"
        action [Hide("display_text"), Jump("pictureframe")]
        hovered Show("display_text", displayText="a picture frame")
        unhovered Hide("display_text")

    # kitchen
    imagebutton:
        xanchor 0.5
        yanchor 0.5
        xpos 0.85
        ypos 0.6
        idle "idle door"
        hover "hover door"
        action [Play("sound", "sfx_door.mp3"), Hide("display_text"), Jump("kitchen")]
        hovered Show("display_text", displayText="the kitchen")
        unhovered Hide("display_text")

    # bedroom
    imagebutton:
        xanchor 0.5
        yanchor 0.5
        xpos 0.719
        ypos 0.549
        idle "idle door"
        hover "hover door"
        action [Play("sound", "sfx_door.mp3"), Hide("display_text"), Jump("bedroom")]
        hovered Show("display_text", displayText="the bedroom")
        unhovered Hide("display_text")

    # trash bag
    imagebutton:
        xanchor 0.5
        yanchor 0.5
        xpos 0.32
        ypos 0.65
        idle "bag4 button"
        hover "bag4 hover"
        action [Hide("display_text"), Jump("trashbag")]
        hovered Show("display_text", displayText="trash bag")
        unhovered Hide("display_text")

    # window
    imagebutton:
        xanchor 0.5
        yanchor 1.0
        pos (110, 866) 
        idle "idle window living"
        hover "hover window living"
        action [Hide("display_text"), Jump("windowliving")]
        hovered Show("display_text", displayText="window")
        unhovered Hide("display_text")


label windowliving:
    scene bg window living_room with fade
    "You look outside."
    "It's almost dark now."
    scene bg livingroom with dissolve
    call screen living_room

label bathroom:
    scene bg bathroom
    call screen bathroom

label trashbag:
    "It's a trash bag full of thing as you can expect,trash."
    show me smirk
    me "I should clean all of them soon. They make my house looks like a dumpster."
    me "..."
    show me anxiety
    me "Maybe tomorrow."
    show me blank
    call screen living_room

screen bathroom:
    add "bg bathroom" at fade_in_bg
    
    # mirror
    imagebutton:
        xanchor 0.5
        yanchor 1.0
        pos (328, 1098) 
        idle "idle mirror"
        hover "hover mirror"
        action [Hide("display_text"), Jump("mirror")]
        hovered Show("display_text", displayText="mirror")
        unhovered Hide("display_text")
        
    # bath
    imagebutton:
        xanchor 0.5
        yanchor 1.0
        pos (1366, 1080) 
        idle "idle bath"
        hover "hover bath"
        action [Hide("display_text"), Jump("bath")]
        hovered Show("display_text", displayText="bath")
        unhovered Hide("display_text")
        
    # bedroom
    imagebutton:
        xanchor 0.5
        yanchor 0.5
        xpos 0.24
        ypos 0.945
        idle "idle door"
        hover "hover door"
        action [Play("sound", "sfx_door.mp3"), Hide("display_text"), Jump("bedroom")]
        hovered Show("display_text", displayText="the bedroom")
        unhovered Hide("display_text")

label bath:
        scene bg bathroom
        show me side_eyes
        me "I don't want to shower at the moment."
        show me blank
        call screen bathroom

label TV:
    scene bg tv with fade
    pause 2.0
    "\"Hey! This is Telev, and this is the NEWS Report. As always, I'll be your one and only reporter for the show.\""
    "\"Stay tuned, because it's... REPORT TIME!\""
    "\"Breaking news: The facility on the outskirts exploded just thirty minutes ago.\""
    "\"Details are still hidden, as authorities have shut off the entire area and are only allowing emergency personnel near the site.\""
    "\"Officials state the situation will be under control shortly, due to the recent rainfall.\""
    "\"The Mayor advises all residents to stay indoors. If you notice anything unusual, please contact the hotline at 4747 immediately.\""

    show me side_eyes
    me "That facility? That's not far from here at all."
    show me got_it
    me "Honestly, that place has always given me a suspicious vibe."
    show me idle
    me "I just hope no one was seriously injured."
    show me what
    me "But why are they telling us to be so cautious? It's strange..."
    me "Sound like they're hiding something?"
    show me idle
    me "Maybe I'm just overthinking it."
    show me blank
    call screen living_room

label news:
    scene bg livingroom
    show me idle
    me "Who still read newspapers these days?"
    me "We have TV now, so this is just a waste of money."
    show me smirk
    me "I should give it a try though, since I already bought it."
    show me side_eyes
    me "I mean I can't leave the paperboy to starve right?"
    scene bg news with fade
    "{b}19th June 1997: Weather Report{/b} In the next few days, you should not go outside without an umbrella."
    "Windy and stormy weather is expected. Strong north-easterly winds will blow, and cloud cover will blanket the entire area. Meteorologists predict that rain is unavoidable..."
    show me stunned
    me "It's the 19th... wait, this is the same day as."
    show me serious
    me "Ugh!"
    show me anxiety
    me "I shouldn't be thinking about this."
    me "Was the drug a scam?"
    show me idle
    me "Hmm. Not like I really care."
    scene bg livingroom with fade
    call screen living_room

label door:

    scene bg door with fade
    show me side_eyes
    me "I don't want to go outsite."
    me "I have no friends to hang out plus it's already dark outside."
    scene bg livingroom with fade
    call screen living_room

label backdoor:

    scene bg kitchen
    show me idle
    me "There's a trash can at the back of this house."
    show me smirk
    me "It's probably cleaner than here though."
    
    call screen kitchen

label pictureframe:
    scene bg livingroom
    show me shock
    me "..."
    show me anxiety
    me "..."
    call screen living_room



label kitchen:
    scene bg kitchen with dissolve
    if kitchen_clicked == False:
        show me smirk
        me "I want to use this room to its full potential one day."
        show me anxiety
        me "But I don't think it's going to happen anytime soon."
        me "Cooking is not my forte."
        me "Because I..."
        show me side_eyes
        me "Never mind. Forget about it."
        $ kitchen_clicked = True
        call screen kitchen
    else:
        call screen kitchen

label mirror:
    if mirror_clicked == False:
        scene bg mirror1 with fade 
        "You look into the mirror."
        scene bg mirror2 with dissolve
        "You realize you've changed so much over the years."
        "But you try not to dwell on it."
        $ mirror_clicked = True
        jump mirror1
    else:
        scene bg mirror3
        "You stare at your reflection."
        "[player_name]."
        call screen bathroom




label mirror1:

    $ player_name = renpy.input("What is your character's name?").strip()
    
    if player_name == "":
        $ player_name = "Dust"
    
    if player_name in ["Mrs.", "Mrs", "mrs.", "mrs"]:
        show me anxiety
        me "Hmm? Is this really my name? This feels really wrong."
        $ persistent.achievement4 = True
        scene black with fade
        lady "Well, well, well~ What is this?"
        pause 0.5
        show mrs idle with moveinleft
        show me shock
        me "?!"
        show mrs impressed with dissolve
        mrs "It seems like someone really misses me."
        show mrs tired with dissolve
        mrs "But you can't impersonate me, you know?"
        $ player_name = "Me"
        me "What's going on?"
        show mrs think with dissolve
        mrs "I guess I have no choice."
        show mrs show with dissolve
        mrs "I have to exterminate {i}you{/i} since you know too much."
        show mrs idle with dissolve
        pause 1.0
        show mrs idle_tf with dissolve
        pause 0.5
        show mrs smile_tf with dissolve
        mrs "Maybe next time~ we'll meet again."
        window hide
        show mrs jumpscare at zoomin100
        with vpunch
        pause 0.1
        show blood1 at zoomin200
        pause 0.1
        show blood2 at zoomin100
        pause 1.0
        scene black with dissolve
        pause 1.0
        play sound 'audio/sfx_bell.mp3'

        $ renpy.notify("Achievement unlocked - 'Maybe next time~'")
        

        "You died."
        
        pause 2.0
        return



        
    show me talk
    me "Everything will be alright, [player_name]."
    $ name = True
    
    jump mirror2
    


label mirror2:
    scene bg mirror3 with fade
    "You see the picture of yourself distorted to the point you can't recognise."
    "Maybe it's just because of eye strain."
    "Maybe it's not."
    scene bg mirror1 with dissolve
    
    show me idle
    me " Whatever."
    
    scene bg bathroom with dissolve 
    call screen bathroom



label bedroom:
    scene bg bedroom with dissolve
    if bedroom_clicked == False:
        show me stunned
        me "Here's the bedroom."
        me "It's where I spend most of my time."
        show me anxiety
        me "I wish I didn't."
        $ bedroom_clicked = True
        call screen bedroom
    else:
        call screen bedroom

label bed:
    show me accept
    me "Just looking at the bed makes me want to pass out."
    show me idle
    me "Seriously, who on earth hates sleep?"
    me "It's the ultimate hobby. The only one that actually pauses your existence..."
    show me talk
    me "..."
    show me smirk
    me "Well, when I thought about it, weed does that too but you know what I mean."
    call screen bedroom


screen bedroom:
    add "bg bedroom" at fade_in_bg

    # bed
    imagebutton:
        xanchor 0.5
        yanchor 1.0
        pos (515, 1056) 
        idle "idle bed"
        hover "hover bed"
        action [Hide("display_text"), Jump("bed")]
        hovered Show("display_text", displayText="bed")
        unhovered Hide("display_text")

    # phone
    imagebutton:
        xanchor 0.5
        yanchor 1.0
        pos (273, 906) 
        idle "idle phone"
        hover "hover phone"
        action [Hide("display_text"), Jump("phone")]
        hovered Show("display_text", displayText="phone")
        unhovered Hide("display_text")

    # clock
    imagebutton:
        xanchor 0.5
        yanchor 1.0
        pos (185, 890) 
        idle "idle clock"
        hover "hover clock"
        action [Hide("display_text"), Jump("clock0")]
        hovered Show("display_text", displayText="table clock")
        unhovered Hide("display_text")

    # computer
    imagebutton:
        xanchor 0.5
        yanchor 1.0
        pos (1121, 858) 
        idle "idle computer"
        hover "hover computer"
        action [Hide("display_text"), Jump("computer")]
        hovered Show("display_text", displayText="computer")
        unhovered Hide("display_text")

    # window 
    imagebutton:
        xanchor 0.5
        yanchor 1.0
        pos (710, 701) 
        idle "idle window bed"
        hover "hover window bed"
        action [Hide("display_text"), Jump("windowbed")]
        hovered Show("display_text", displayText="windowbed")
        unhovered Hide("display_text")

    # bathroom
    imagebutton:
        xanchor 0.5
        yanchor 0.5
        xpos 0.85
        ypos 0.55
        idle "idle door"
        hover "hover door"
        action [Play("sound", "sfx_door.mp3"), Hide("display_text"), Jump("bathroom")]
        hovered Show("display_text", displayText="the bathroom")
        unhovered Hide("display_text")

    # living room
    imagebutton:
        xanchor 0.5
        yanchor 0.5
        xpos 0.8
        ypos 0.9
        idle "idle door"
        hover "hover door"
        action [Play("sound", "sfx_door.mp3"), Hide("display_text"), Jump("livingroom1")]
        hovered Show("display_text", displayText="the living room")
        unhovered Hide("display_text")

    # trash bag
    imagebutton:
        xanchor 0.5
        yanchor 0.5
        xpos 0.9
        ypos 0.95
        idle "bag3 button"
        hover "bag3 hover"
        action [Hide("display_text"), Jump("trashbag2")]
        hovered Show("display_text", displayText="trash bag")
        unhovered Hide("display_text")
    
screen kitchen:
    add "bg kitchen" at fade_in_bg
    # back door
    imagebutton:
        xanchor 0.5
        yanchor 0.5
        xpos 0.33
        ypos 0.53
        idle "idle door"
        hover "hover door"
        action [Hide("display_text"), Jump("backdoor")]
        hovered Show("display_text", displayText="a back door")
        unhovered Hide("display_text")
    # cabinet
    imagebutton:
        pos (1130, 841) 
        xanchor 0.5
        yanchor 1.0
        idle "idle cabinet"
        hover "hover cabinet"
        action [Jump("cabinet")]
    #living room
    imagebutton:
        xanchor 0.5
        yanchor 0.5
        xpos 0.23
        ypos 0.945
        idle "idle door"
        hover "hover door"
        action [Play("sound", "sfx_door.mp3"), Hide("display_text"), Jump("livingroom1")]
        hovered Show("display_text", displayText="the living room")
        unhovered Hide("display_text")
    # trash bag
    imagebutton:
        xanchor 0.5
        yanchor 0.5
        xpos 0.8
        ypos 0.9
        idle "bag2 button"
        hover "bag2 hover"
        action [Hide("display_text"), Jump("trashbag3")]
        hovered Show("display_text", displayText="trash bag")
        unhovered Hide("display_text")
    # trash bag
    imagebutton:
        xanchor 0.5
        yanchor 0.5
        xpos 0.4
        ypos 0.75
        idle "bag1 button"
        hover "bag1 hover"
        action [Hide("display_text"), Jump("trashbag3")]
        hovered Show("display_text", displayText="trash bag")
        unhovered Hide("display_text")
label cabinet:
    scene bg kitchen
    if not knife_recieved:
        "You open the cabinet."
        show knife with dissolve
        "You find {b}a knife{/b}."


    
    call screen knife_continue




screen knife_continue:
    frame:
        xalign 0.5
        yalign 0.5
        xysize (650, 400)
        background Solid("#a0a0a0") 
        
        frame:
            xalign 0.5
            yalign 0.5
            xysize (645, 395)
            background Solid("#050505") 
            padding (60, 40)

            vbox:
                xalign 0.5
                yalign 0.5
                spacing 20
                


                
                
                null height 15
                text "{b}Do you want to keep it?" size 28 color "#ffffff" xalign 0.5
                hbox:
                    xalign 0.5
                    spacing 200
                    
                    textbutton "Yes":
                        text_size 40 
                        text_color "#00ff08" 
                        text_hover_color "#ffffff"
                        text_bold True
                        action [Play("sound", "sfx_knife.mp3"), Jump("choices1_a")]
                        
                    textbutton "No":
                        text_size 40 
                        text_color "#ff0000" 
                        text_hover_color "#ffffff"
                        text_bold True
                        action [Play("sound", "sfx_no.mp3"), Jump("choices1_b")]

label choices1_a:
    show me angry
    me "I have a hunch I'm going to need this soon."
    me "Better safe than sorry."
    $ knife_recieved = True
    scene bg kitchen with dissolve
    call screen kitchen

label choices1_b:
    show me anxiety
    me "That can't be a good idea."
    me "I don't want to accidentally stab myself in my sleep."
    $ knife_recieved = False
    scene bg kitchen with dissolve
    call screen kitchen

label clock0:
    $ hour = 18
    $ minute = 20
    call screen table_clock

label phone:
    show me idle
    me "My phone."
    show me talk
    me "I still can't believe these things used to be so huge and heavy."
    me "It's way more convenient now that you can use it outside the house."
    me "I don't remember ever using it outside though."
    show me idle
    me "..."
    show me anxiety
    me "The older models were so much cheaper... why did I even buy this?"
    call screen bedroom

label trashbag2:
    show me smirk
    me "Keeping trash bags in the bedroom is a little extreme, honestly."
    show me idle
    me "..."
    show me side_eyes
    me "Not that I'm actually going to take them out anytime soon."
    call screen bedroom

label trashbag3:
    show me idle
    me "Trash bags in the kitchen are normal."
    me "Right? Yeah, totally normal."
    call screen kitchen

label windowbed:
    scene bg window
    "Even though you can't see outside clearly,"
    "It feels like something is staring back at you."
    "But it's probably just your imagination."
    call screen bedroom

label livingroom1:
    call screen living_room

label computer:
    if not name:
        show me talk
        me "I haven't cleaned my face yet."
        me "Shouldn't be too hasty."
        call screen bedroom

    scene bg bedroom
    show me side_eyes
    me "I should search up the internet, maybe I'll find something interesting."
    scene bg computer with fade
    pause 1.0
    
    scene bg com 0
    play sound 'audio/sfx_am2.mp3'volume 0.03
    pause 0.5
    scene bg com load
    pause 5.0
    scene bg computer
    pause 2.0
    
    call screen desktop
screen desktop:
    tag computer
    add "bg desktop" at fade_in_bg
    # icon
    imagebutton:
        xanchor 0.5
        yanchor 1.0
        pos (600, 813) 
        idle "idle icon"
        hover "hover icon"
        action [Show("screen_gooble")]


screen screen_gooble:
    tag computer
    add "bg computer" at fade_in_bg
    frame:
        xalign 0.6
        yalign 0.5
        xysize (1300, 900)
        background Frame("bg interface.png", 100, 100)
        padding (200, 200)

    add "gooble.png" xalign 0.55 yalign 0.5 
    if not bar_clicked:
        #bar
        imagebutton:
            xalign 0.55 yalign 0.7 
            idle "search bar 1"
            hover "hover bar"
            action [SetVariable("bar_clicked", True),]

    if bar_clicked:
        add "search bar 1.png" xalign 0.55 yalign 0.7 
        text "Interesting activities to pass time." size 16 color "#000000" xalign 0.462 yalign 0.695 slow_cps 10

        imagebutton:
            xanchor 0.5
            yanchor 1.0
            pos (1242, 858) 
            idle "idle search"
            hover "hover search"
            action [Show("screen_searching")]

            



screen screen_searching:
    tag computer
    frame:
        xalign 0.6
        yalign 0.5
        xysize (1300, 900)
        background Frame("bg interface.png", 100, 100)
        padding (200, 200) 
        add "search bar 1.png"  yalign 0.055 zoom 0.6 
        text "Interesting activities to pass time." size 12 color "#707070" xalign 0.035  yalign 0.1

        vbox:
            spacing 30
            
            null height 70

            vbox:
                textbutton "{u}10 most popular hobbies!{/u}":
                    text_size 28 text_color "#1a0dab" text_hover_color "#d61a1a"
                    action Notify("These are normal hobbies.")
                text "Yoga, drawing, cooking, ..." size 18 color "#545454"

            vbox:
                textbutton "{u}A normal list of activities.{/u}":
                    text_size 28 text_color "#1a0dab" text_hover_color "#d61a1a"
                    action Notify("These also aren't realistic.")
                text "Activities such as filmmaking, swimming, ..." size 18 color "#545454"

            vbox:
                textbutton "{u}Best way to spend your time!{/u}":
                    text_size 28 text_color "#1a0dab" text_hover_color "#d61a1a"
                    action Notify("I don't have friends.")
                text "Playing card games is the best way to..." size 18 color "#545454"
                
            vbox:
                textbutton "{u}101 Fun Hobbies{/u}":
                    text_size 28 text_color "#1a0dab" text_hover_color "#d61a1a"
                    action Notify("Wow, one hundred and one, and all of them are trash! Great!")
                text "1. Eating 2. Walking 3. Running 4. Hiking 5. Picnicking 6. Dancing..." size 18 color "#545454"
            
            vbox:
                textbutton "{u}All Hobbies: The Novel{/u}":
                    text_size 28 text_color "#1a0dab" text_hover_color "#d61a1a"
                    action Notify("This sounds like a story with no tomorrow.")
                text "Roughly a million years from now, mankind meets a godly creature from outer space that can change genetic codes at will... " size 18 color "#545454"


            hbox:
                xalign 0.5
                spacing 15
                
                text "Gooooooble" size 40 color "#1a0dab" xalign 0.5
                
                hbox:
                    spacing 10
                    yalign 1.0
                    text "1" size 20 color "#000000"
                    text "2" size 20 color "#1a0dab"
                    text "3" size 20 color "#1a0dab"
                    text "4" size 20 color "#1a0dab"
                    text "..." size 20 color "#000000"
                    text "124" size 20 color "#1a0dab"
                    
                    imagebutton:
                        idle Text(">>", size=20, color="#1a0dab", underline=True)
                        hover Text(">>", size=20, color="#ff0000", underline=True)
                        action [Hide("display_text"), Hide("screen_searching"), Show("screen_searching2")]
                        hovered Show("display_text", displayText="I should continue searching.")
                        unhovered Hide("display_text")

screen screen_searching2:
    tag computer
    frame:
        xalign 0.6
        yalign 0.5
        xysize (1300, 900)
        background Frame("bg interface.png", 100, 100)
        padding (200, 200) 
        add "search bar 1.png"  yalign 0.055 zoom 0.6 
        text "Interesting activities to pass time." size 12 color "#707070" xalign 0.035  yalign 0.1

        vbox:
            spacing 30
            
            null height 70

            vbox:
                textbutton "{u}Beware of a tall lady.{/u}":
                    text_size 28 text_color "#1a0dab" text_hover_color "#d61a1a"
                    action [Notify("This one isn't even related to what I searched for."),SetVariable("persistent.achievement3", True)]
                text "If you find a person in that description, don't let her in. This is a warning..." size 18 color "#545454"

            vbox:
                textbutton "{u}How to defend yourself against Demons.{/u}":
                    text_size 28 text_color "#1a0dab" text_hover_color "#d61a1a"
                    action Notify("Another one?")
                text "Demons like mortals who are witty, so we recommend that you be one. They are also usually scared of fire..." size 18 color "#545454"

            vbox:
                textbutton "{u}Hobbies? You should care more about finding job.{/u}":
                    text_size 28 text_color "#1a0dab" text_hover_color "#d61a1a"
                    action Notify("What the heck dude!")
                text "Here's job application, take it or leave it..." size 18 color "#545454"

            vbox:
                textbutton "{u}{b}Completely normal hobbies.{/u}":
                    text_size 28 text_color "#1a0dab" text_hover_color "#d61a1a"
                    action [Hide("display_text"),Jump("site1")]
                    hovered Show("display_text", displayText="This is the last one, I hope I'll find anything worth my time.")
                    unhovered Hide("display_text")
                text "All of these are normal activities, nothing to see here. Go away!" size 18 color "#545454"

            null height 50 

            hbox:
                xalign 0.5
                spacing 15
                
                text "Gooooooble" size 40 color "#1a0dab" xalign 0.5
                
                hbox:
                    spacing 10
                    yalign 1.0
                    text "<<" size 20 color "#1a0dab"
                    text "1" size 20 color "#1a0dab"
                    text "..." size 20 color "#1a0dab"
                    text "121" size 20 color "#1a0dab"
                    text "122" size 20 color "#1a0dab"
                    text "123" size 20 color "#1a0dab"
                    text "124" size 20 color "#000000"
                    
                
screen site1:
    tag computer
    frame:
        xalign 0.5
        yalign 0.5
        xysize (1305, 905)
        background Solid("#a0a0a0") 


    frame:
        xalign 0.5
        yalign 0.5
        xysize (1300, 900)
        
        background Solid("#000000") 
        padding (80, 50)
    
        
        vbox:
            spacing 15
            
            hbox:
                xfill True
                text "httq://www.678-shadow-absolute-secret.net" size 16 color "#666666"
                text"Exit{b}X{/b}" color "#ff0000" xalign 0.9

            null height 10
            frame:
                background Solid("#1a0000")
                padding (20, 20)
                xfill True
                vbox:
                    text "{b}WELCOME TO THE ORDINARY WEBSITE" size 45 color "#ff0000" xalign 0.5
                    

            

            vbox:
                spacing 5
                text "{i}Completely normal activities to light up your mood.{/i}" size 24 color "#cccccc"
                text "____________________________________________________" color "#444444"
                text ""
                text "1. Resurructing" size 26 color "#ffffff"
                text "2. playing Ouija board" size 26 color "#ffffff"
                text "3. Lucid dreaming"size 26 color "#ffffff"
                if not sleep_paralysis_web_clicked:
                    textbutton "4. {b}Inducing Sleep paralysis{/b}":
                        text_size 26 text_color "#dcdcdc" text_hover_color "#d61a1a"
                        action [Play("sound", "sfx_no.mp3"),  SetVariable("sleep_paralysis_web_clicked", True)]
                if sleep_paralysis_web_clicked:
                    text "4. {i}Inducing Sleep paralysis{/i}" size 26 color "#ff0000"
            
                text "5. Observing the ???" size 26 color "#ffffff"
            null height 30
            if sleep_paralysis_web_clicked:
                vbox:
                    spacing 8
                    text "{b}HOW TO INDUCE SLEEP PARALYSIS{/b}" size 32 color "#ff0000" 
                    text "NOT RECOMMENDED TO TRY THIS YOURSELF." size 20 color "#ffffff" italic True
                vbox:
                    spacing 5
                    text "• This procedure is dangerous; proceed with caution." size 22 color "#aaaaaa"
                    text "• EVERYTHING YOU WILL SEE IS NOT REAL." size 26 color "#ff0000" bold True

        if sleep_paralysis_web_clicked:
            vbox:
                imagebutton:
                        pos (150, 870) 
                        xanchor 0.5
                        yanchor 1.0
                        idle "button_idle"
                        hover "button_hover"
                        action [ Play("sound", "sfx_no.mp3"), Hide("computer"), Hide("display_text"), Jump("site2")]
                        hovered Show("display_text", displayText="Proceed")
                        unhovered Hide("display_text")

label site1:
    
    if persistent .achievement3 and not persistent .achievement3_notify:
        play sound 'audio/sfx_bell.mp3'
        $ renpy.notify("Achievement unlocked3 - 'Wrong game'")
        $ persistent .achievement3_notify = True
        call screen site1
    else:
        call screen site1
label site2:
    call screen site2
screen site2:
    tag computer
    frame:
        xalign 0.5
        yalign 0.5
        xysize (1305, 905)
        background Solid("#a0a0a0") 
    frame:
        xalign 0.5
        yalign 0.5
        xysize (1300, 900)
        background Solid("#050505") 
        padding (60, 40)

        vbox:
            spacing 20
            
 
            hbox:
                xfill True
                text "LOG_FILE: SFR_confidential_info.txt" size 14 color "#666666" 
                textbutton "DISCONNECT{b}X{/b}" action [Play("sound", "sfx_yes.mp3"), Jump("computer1")] xalign 1.0 text_size 30 text_color "#ff0000" text_hover_color "#ffffff"
        

            null height 10
            
      
            text "PHASE II: INDUCTION PROTOCOL" size 34 color "#cccccc" bold True xalign 0.0

            vbox:
                spacing 12
     
                text "01. Make yourself tired." size 26 color "#bbbbbb"
                text "02. Disrupt the sleep cycle." size 26 color "#bbbbbb"
                text "03. Keep reminding yourself about sleep paralysis." size 26 color "#bbbbbb"
                text "04. Relax your limbs." size 26 color "#bbbbbb"
                text "05. Fall asleep." size 26 color "#bbbbbb"
                
           
                null height 5
                text "06. DON'T SPEAK WITH IT." size 32 color "#ff0000" bold True kerning 2
            
            null height 30

            frame:
                background Solid("#1a0000")
                padding (20, 20)
                xfill True
                vbox:
                    text "CRITICAL WARNING:" size 18 color "#ff5555" bold True
                    text "The worst possible outcome may result in permanent mental distress." size 22 color "#ff5555" italic True



        



label computer1:
    scene bg desktop with dissolve
    show me anxiety
    me "This website looks really suspicious."
    show me angry
    me "What do you even mean by an 'absolute-secret.net'?"
    show me smirk
    me "What kind of secret organization calls itself a secret organization?"
    me "I'm at a loss for words looking at these suggested hobbies."
    me "..."
    show me talk
    me "Maybe it's the norm somewhere."
    show me smirk
    me "Like Hell."
    show me talk
    me "Though, sleep paralysis is kind of piquing my interest."
    me "Compared to the others, it doesn't sound that bad."
    me "Maybe I should try it myself."
    show me stunned
    me "Nothing could go wrong, right?"
    show me idle
    me "..."
    show me talk
    me "I shouldn't have said that."
    me "I just put a red flag on myself."
    show me idle
    me "Nice."
    me "Anyway."
    show me side_eyes
    me "I should start by making myself feel tired."
    me "Hmm... What should I do."
    show me got_it
    me "Oh!"
    me "I should clean my house. I'll kill two birds with one stone."
    scene bg computer with dissolve
    "{b}Collect all the trash bags and put them outside the house.{/b}"
    scene bg bedroom with dissolve
    call screen bedroom2



screen bedroom2:
    add "bg bedroom" at fade_in_bg
    if not throw_out_trash:
        frame:
            align (0.98, 0.02)
            text "Score: [score]/4" size 24 color "#FFFFFF"
        # bathroom
    imagebutton:
        xanchor 0.5
        yanchor 0.5
        xpos 0.85
        ypos 0.55
        idle "idle door"
        hover "hover door"
        action [Play("sound", "sfx_door.mp3"), Hide("display_text"), Jump("bathroom2")]
        hovered Show("display_text", displayText="the bathroom")
        unhovered Hide("display_text")
    
    #living room
    imagebutton:
        xanchor 0.5
        yanchor 0.5
        xpos 0.8
        ypos 0.9
        idle "idle door"
        hover "hover door"
        action [Play("sound", "sfx_door.mp3"), Hide("display_text"), Jump("livingroom2")]
        hovered Show("display_text", displayText="the living room")
        unhovered Hide("display_text")
    # trash bag
    
    if not trash_bedroom_clicked:
        imagebutton:
            xanchor 0.5
            yanchor 0.5
            xpos 0.9
            ypos 0.95
            idle "bag3 button"
            hover "bag3 hover"
            action [Play("sound", "sfx_trash.mp3"), Hide("display_text"),SetVariable("trash_bedroom_clicked", True),SetVariable("score", score + 1)]
            hovered Show("display_text", displayText="trash bag")
            unhovered Hide("display_text")

label bathroom2:
    if not throw_out_trash: 
        scene bg bathroom with dissolve
        show me idle
        me "No trash bags here."
        show me talk
        me "I should check other rooms."
        call screen bathroom2


    else:
        call screen bathroom2
label bath2:
    if not throw_out_trash:
        scene bg bathroom
        show me idle
        me "I should take a shower after I finish collecting all the trash bags."
        call screen bathroom2
    else:
        scene bg bathroom
        play sound 'audio/sfx_shower.mp3'
        "You take a shower."
        scene black with dissolve
        "{i}15 minutes later.{/i}"
        stop sound
        scene bg bedroom with dissolve
        show me accept
        me "Phew. I feel a lot better now."
        me "To clear your mind, you have to cleanse your body first."
        show me talk
        me "Ahem- let's see what I have to do next."
        me "The next step is..."
        show me stunned
        me "\"Disrupt the sleep cycle.\""
        me "Hmm..."
        show me side_eyes
        me "I suppose I'll have to use my {b}table clock{/b} for that."
        me "{b}Half past one{/b} should work just fine."
        $ beforebed = False
        $ hour = 19
        $ minute = 6
        call screen table_clock

label mirror3:
    scene bg mirror3 with dissolve
    "You look into the mirror."
    "You saw yourself."
    scene bg mirror1 with dissolve
    show me smirk
    me " What did I expect to see?"
    call screen bathroom2        

screen bathroom2:
    add "bg bathroom2" at fade_in_bg
    if not throw_out_trash:
        frame:
            align (0.98, 0.02)
            text "Score: [score]/4" size 24 color "#FFFFFF"
    if not puddle_clicked:
        imagebutton:
            xanchor 0.5
            yanchor 1.0
            pos (816, 1101) 
            idle "idle puddle"
            hover "hover puddle"
            action [Play("sound", "sfx_yes.mp3"),SetVariable("puddle_clicked", True),]
    # mirror
    imagebutton:
        xanchor 0.5
        yanchor 1.0
        pos (328, 1098) 
        idle "idle mirror"
        hover "hover mirror"
        action [Hide("display_text"), Jump("mirror3")]
        hovered Show("display_text", displayText="mirror")
        unhovered Hide("display_text")
    # bath
    imagebutton:
        xanchor 0.5
        yanchor 1.0
        pos (1366, 1080) 
        idle "idle bath"
        hover "hover bath"
        action [Hide("display_text"), Jump("bath2")]
        hovered Show("display_text", displayText="bath")
        unhovered Hide("display_text")
    #bedroom
    imagebutton:
        xanchor 0.5
        yanchor 0.5
        xpos 0.24
        ypos 0.945
        idle "idle door"
        hover "hover door"
        action [Play("sound", "sfx_door.mp3"), Hide("display_text"), Jump("bedroom2")]
        hovered Show("display_text", displayText="the bedroom")
        unhovered Hide("display_text")


label bedroom2:
    scene bg bedroom
    call screen bedroom2

label kitchen2:
    scene bg kitchen
    call screen kitchen2    

label livingroom2:
    scene bg livingroom
    call screen living_room2

screen living_room2:
    add "bg livingroom2" at fade_in_bg
    if not throw_out_trash:
        frame:
            align (0.98, 0.02)
            text "Score: [score]/4" size 24 color "#FFFFFF"
    
    # web
    if not web_clicked:
        imagebutton:
            xanchor 0.5
            yanchor 1.0
            pos (1506, 485) 
            idle "idle web"
            hover "hover web"
            action [Play("sound", "sfx_yes.mp3"), SetVariable("web_clicked", True)]

    # door
    imagebutton:
        xanchor 0.5
        yanchor 0.5
        xpos 0.14
        ypos 0.6
        idle "idle door"
        hover "hover door"
        action [Hide("display_text"), Jump("door2")]
        hovered Show("display_text", displayText="an entrance")
        unhovered Hide("display_text")
 
    # kitchen
    imagebutton:
        xanchor 0.5
        yanchor 0.5
        xpos 0.85
        ypos 0.6
        idle "idle door"
        hover "hover door"
        action [Play("sound", "sfx_door.mp3"), Hide("display_text"), Jump("kitchen2")]
        hovered Show("display_text", displayText="the kitchen")
        unhovered Hide("display_text")

    # bedroom
    imagebutton:
        xanchor 0.5
        yanchor 0.5
        xpos 0.719
        ypos 0.549
        idle "idle door"
        hover "hover door"
        action [Play("sound", "sfx_door.mp3"), Hide("display_text"), Jump("bedroom2")]
        hovered Show("display_text", displayText="the bedroom")
        unhovered Hide("display_text")

    # trash bag
    if not trash_living_clicked:
        imagebutton:
            xanchor 0.5
            yanchor 0.5
            xpos 0.32
            ypos 0.65
            idle "bag4 button"
            hover "bag4 hover"
            action [Play("sound", "sfx_trash.mp3"), Hide("display_text"), SetVariable("trash_living_clicked", True), SetVariable("score", score + 1)]
            hovered Show("display_text", displayText="trash bag")
            unhovered Hide("display_text")

label door2:
    scene bg door with fade
    show me idle
    me "If I remember correctly, trash can is behind the house."
    scene bg livingroom2 with dissolve
    call screen living_room2

screen kitchen2:
    add "bg kitchen" at fade_in_bg
    if not throw_out_trash:
        frame:
            align (0.98, 0.02)
            text "Score: [score]/4" size 24 color "#FFFFFF"

    # door
    imagebutton:
        xanchor 0.5
        yanchor 0.5
        xpos 0.33
        ypos 0.53
        idle "idle door"
        hover "hover door"
        action [Hide("display_text"), Jump("backdoor2")]
        hovered Show("display_text", displayText="a back door")
        unhovered Hide("display_text")
    
    # living room
    imagebutton:
        xanchor 0.5
        yanchor 0.5
        xpos 0.23
        ypos 0.945
        idle "idle door"
        hover "hover door"
        action [Play("sound", "sfx_door.mp3"), Hide("display_text"), Jump("livingroom2")]
        hovered Show("display_text", displayText="the living room")
        unhovered Hide("display_text")

    # trash bag 1
    if not trash_kitchen_clicked1:
        imagebutton:
            xanchor 0.5
            yanchor 0.5
            xpos 0.8
            ypos 0.9
            idle "bag2 button"
            hover "bag2 hover"
            action [Play("sound", "sfx_trash.mp3"), Hide("display_text"), SetVariable("trash_kitchen_clicked1", True), SetVariable("score", score + 1)]
            hovered Show("display_text", displayText="trash bag")
            unhovered Hide("display_text")

    # trash bag 2
    if not trash_kitchen_clicked2:
        imagebutton:
            xanchor 0.5
            yanchor 0.5
            xpos 0.4
            ypos 0.75
            idle "bag1 button"
            hover "bag1 hover"
            action [Play("sound", "sfx_trash.mp3"), Hide("display_text"), SetVariable("trash_kitchen_clicked2", True), SetVariable("score", score + 1)]
            hovered Show("display_text", displayText="trash bag")
            unhovered Hide("display_text")


    
label backdoor2:
    if score >= click_goal:
        if web_clicked == True and puddle_clicked == True:
            play sound 'audio/sfx_bell.mp3'
            $ renpy.notify("Achievement unlocked - 'Neat and tidy'")
            $ persistent.achievement1 = True
        scene bg kitchen
        show me accept
        me "Phew.. I did it!"
        me "That was easier than I thought."
        show me idle
        me "I should have done this a week ago."
        me "That's only the first step though."
        me "The rest can be done in bed."
        me "I should probably take a shower before proceeding."
        $ throw_out_trash = True
        call screen kitchen2
    else:
        show me anxiety
        me "It's not done yet."
        me "I can't stop right now."
        
        call screen kitchen2
screen table_clock:

    add "bg clock" at fade_in_bg

    frame:
        background None
        align (0.5, 0.52)
        text "[hour:02d]:[minute:02d]" size 200 color "#00eea7"
    
    if beforebed:
        textbutton "Go back":
            xanchor 0.5
            yanchor 0.5
            xpos 0.7
            ypos 0.7

            action [Jump("bedroom")]


    # button hour
    if not beforebed:
        imagebutton:
            xanchor 0.5
            yanchor 0.5
            xpos 0.635
            ypos 0.2
            idle "button_clock idle"
            hover "button_clock clicked"
            action [Play("sound", "sfx_button.mp3"), Hide("display_text"), SetVariable("hour", (hour + 1) % 24)]
            hovered Show("display_text", displayText="Add an hour")
            unhovered Hide("display_text")
            
            

        # button minute
        imagebutton:
            xanchor 0.5
            yanchor 0.5
            xpos 0.72
            ypos 0.2    
            idle "button_clock idle"
            hover "button_clock clicked"
            action [Play("sound", "sfx_button.mp3"), Hide("display_text"), SetVariable("minute", (minute + 1) % 60)]
            hovered Show("display_text", displayText="Add a minute")
            unhovered Hide("display_text")
            
            
        
        # set_an_alarm
        imagebutton:
            xanchor 0.5
            yanchor 0.5
            xpos 0.42
            ypos 0.2
            idle "button_clock idle2"
            hover "button_clock clicked2"
            action [Play("sound", "sfx_button.mp3"), Hide("display_text"), Jump("set_an_alarm")]
            hovered Show("display_text", displayText="Set an alarm")
            unhovered Hide("display_text")
            
        # set zero
        imagebutton:
            xanchor 0.5
            yanchor 0.5
            xpos 0.5
            ypos 0.2
            idle "button_clock idle2"
            hover "button_clock clicked2"
            action [Play("sound", "sfx_button.mp3"), SetVariable("hour", 0), SetVariable("minute", 0), Hide("display_text")]
            hovered Show("display_text", displayText="Reset time")
            unhovered Hide("display_text")



label set_an_alarm:
    scene black  with dissolve
    if hour == 1 and minute == 30:
        "You set the clock."
        jump sleep
    else:
        show me anxiety
        me "That's not what I intend. I should set it again."
        $ hour = 0
        $ minute = 0
        $ misclick += 1
        if misclick == 3 :
            play sound 'audio/sfx_bell.mp3'
            $ renpy.notify("Achievement unlocked - 'You good bro?'")
            $ persistent.achievement2 = True
        call screen table_clock 

label sleep:
    scene bg sleep with fade
    show me stunned
    me "Alright. The next step is to keep reminding myself about it."
    show me smirk
    me "I don't really believe it works, but I won't know until I try."
    "{b}Keep chanting \"Sleep paralysis\" until you know it by heart.{/b}"
    scene bg blink1 with dissolve
    pause 1.0
    scene bg blink2 with wipedown
    pause 1.0
    scene bg blink3 with wipedown
    pause 1.0
    scene black with dissolve
    pause 1.0
    call screen shanting



default repeating = 0
default xpo = 0.5
default ypo = 0.5

screen shanting:
    add "bg memory" at fade_in_bg

    if repeating == 0:
        textbutton "\"Sleep paralysis\"":
            text_font "VT323-Regular.ttf"
            align (0.5, 0.5)
            action [SetVariable("repeating", repeating + 1),
                SetVariable("xpo", renpy.random.random()), 
                SetVariable("ypo", renpy.random.random()),
                Play("sound", "sfx_tud.mp3")]

    elif repeating < 7:
        textbutton "\"Sleep paralysis\"":
            text_font "VT323-Regular.ttf"
            anchor (0.5, 0.5)
            pos (xpo, ypo)
            
            action [
                SetVariable("repeating", repeating + 1),
                SetVariable("xpo", renpy.random.random()),
                SetVariable("ypo", renpy.random.random()),
                Play("sound", "sfx_bell.mp3")]

    else:
        textbutton "\"Sleep paralysis\"":
            align (0.5, 0.5)
            action [Hide("shanting"),Jump("sleep2")]



screen stretch_minigame(arm_done, leg_done):
    
    frame:
        xalign 0.5 yalign 0.5
        xysize (1920, 1080)
        background Solid("#000000") 

        text "{b}Relax your body." size 50 color "#37ff00" xalign 0.5 yalign 0.5

        draggroup:
            drag:
                drag_name "target_arm"
                child Text("Relax your Arms.", size=25, color="#ffffff", alpha=0.3, outlines=[(2, "#000")])
                draggable False
                droppable True
                xpos 400 ypos 200 anchor (0.5, 0.5)

            drag:
                drag_name "target_leg"
                child Text("Relax your Legs.", size=25, color="#ffffff", alpha=0.3, outlines=[(2, "#000")])
                draggable False
                droppable True
                xpos 1500 ypos 800 anchor (0.5, 0.5)

            drag:
                drag_name "arm"
                child "stretch arm" 
                draggable (not arm_done)
                droppable False
                drag_offscreen True
                dragged stretch_dragged
                
                if arm_done:
                    xpos 1200 ypos 200 anchor (0.5, 0.5)
                else:
                    xpos 2500 ypos 200 anchor (0.5, 0.5)

            drag:
                drag_name "leg"
                child "stretch leg" 
                draggable (not leg_done)
                droppable False
                drag_offscreen True
                dragged stretch_dragged
                
                if leg_done:
                    xpos 620 ypos 800 anchor (0.5, 0.5)
                else:
                    xpos -500 ypos 800 anchor (0.5, 0.5)




label sleep2:
    scene bg sleep 2
    show me got_it

    me "That should be enough."
    show me idle
    me "Now I just need to be relax and go to sleep."
    window hide
    $ arm_is_done = False
    $ leg_is_done = False

    label stretch_loop:
        $ result = renpy.call_screen("stretch_minigame", arm_done=arm_is_done, leg_done=leg_is_done)

        if result == "arm_finished":
            $ arm_is_done = True
        elif result == "leg_finished":
            $ leg_is_done = True

        if not (arm_is_done and leg_is_done):
            jump stretch_loop

    window show
    show me idle
    me "Finally... I can sleep."

    scene black with fade
    show me talk
    me "'I feel better now...'"
    show me close_eyes
    me "'Just keep my eyes closed and let go...'"
    me "'Everything is going to be okay, right?'"
    me "..."
    me "..."
    play music 'audio/music_alarmclock.mp3' volume 0.1
    $ renpy.notify("Ring!")
    pause 0.1
    scene bg sleep 2 with fade
    $ renpy.notify("Ring!")
    pause 0.1
    $ renpy.notify("Ring!")
    pause 0.1
    $ renpy.notify("Ring!")
    pause 0.1
    $ renpy.notify("!")
    
    show me serious
    me "'Ugh- I really hate that sound.'"
    play music 'audio/music_alarmclock.mp3' volume 0.01
    show me anxiety
    me "'I need to turn off the alarm.'"
    show me stunned
    me "'Hmm?'"
    show me shock
    me "'I can't move!'"
    show me stunned
    me "'Oh, right. I forgot I intentionally did this to myself.'"
    show me sigh
    me "'*Sigh*... Why did I think this was a good idea?'"
    show me idle
    me "'Complaining won't change anything.'"
    show me side_eyes
    me "'All I can do right now is look around and see if anything can get me out of this.'"
    show me idle
    me "'Or maybe I'll see some of that {b}weird stuff{/b} they were talking about.'"
    stop music
    scene bg sleep 2 with fade
    window hide

    call screen screen_pre_main_game

screen window_continue:
    frame:
        xalign 0.5
        yalign 0.5
        xysize (700, 500)
        background Solid("#a0a0a0") 
        
        frame:
            xalign 0.5
            yalign 0.5
            xysize (695, 495)
            background Solid("#050505") 
            padding (60, 40)

            vbox:
                xalign 0.5
                yalign 0.5
                spacing 20
                


                text "This action will lead to next part," size 24 color "#ffffff" xalign 0.5
                
                
                null height 15
                text "{b}Do you want to continue?." size 24 color "#ffffff" xalign 0.5
                hbox:
                    xalign 0.5
                    spacing 200
                    
                    textbutton "Yes":
                        text_size 40 
                        text_color "#00ff08" 
                        text_hover_color "#ffffff"
                        text_bold True
                        action [Play("sound", "sfx_yes.mp3"), Jump("window_continue_yes")]
                        
                    textbutton "No":
                        text_size 40 
                        text_color "#ff0000" 
                        text_hover_color "#ffffff"
                        text_bold True
                        action [Play("sound", "sfx_no.mp3"), Jump("window_continue_no")]


label label_window_continue:
    scene bg sleep 2 with dissolve
    call screen window_continue

label window_continue_yes: 
    jump sleep_window  

label window_continue_no: 
    call screen screen_pre_main_game

screen screen_pre_main_game:
    add "bg sleep 2" at fade_in_bg

    # window
    imagebutton:
        xanchor 0.5
        yanchor 1.0
        pos (206, 641) 
        idle "idle sleep window"
        hover "hover sleep window"
        action [Hide("display_text"), Jump("label_window_continue")]
        hovered Show("display_text", displayText="the window")
        unhovered Hide("display_text")

    # wake
    imagebutton:
        xanchor 0.5
        yanchor 1.0
        pos (1030, 896) 
        idle "idle wake"
        hover "hover wake"
        action [Hide("display_text"), Jump("wake_up")]
        hovered Show("display_text", displayText="Move your body")
        unhovered Hide("display_text")

    # left arm
    imagebutton:
        xanchor 0.5
        yanchor 1.0
        pos (418, 1080) 
        idle "left arm"
        hover "hover grab"
        action [Hide("display_text"), Jump("left_arm")]
        hovered Show("display_text", displayText="Move your left arm")
        unhovered Hide("display_text")

    # right arm
    imagebutton:
        xanchor 0.5
        yanchor 1.0
        pos (1520, 1080) 
        idle "right arm"
        hover "hover grab"
        action [Hide("display_text"), Jump("right_arm")]
        hovered Show("display_text", displayText="Move your right arm")
        unhovered Hide("display_text")

    # sleep clock
    imagebutton:
        xanchor 0.5
        yanchor 1.0
        pos (1831, 1055) 
        idle "idle sleep clock"
        hover "hover sleep clock"
        action [Hide("display_text"), Jump("check_clock")]
        hovered Show("display_text", displayText="the clock")
        unhovered Hide("display_text")

    # phone
    imagebutton:
        xanchor 0.5
        yanchor 1.0
        pos (1698, 940) 
        idle "idle sleep phone" 
        hover "hover sleep phone"
        action [Hide("display_text"), Jump("check_phone")]
        hovered Show("display_text", displayText="the phone")
        unhovered Hide("display_text")



label wake_up:
    show me angry
    me "'I need to snap out of this. Come on, my solid tummy made of pure muscle!'"
    show me well
    me "'It's actually 90\%\ fat, but I'll pretend that's not the case.'"
    show me sigh
    me "'*Sigh*.. I still can't move an inch.'"
    show me smirk
    me "'Normally, I can move more inches though.'"
    pause 1.0
    me "'Talking about my legs.'"
    call screen screen_pre_main_game
label left_arm:
    show me anxiety
    me "'My left arm feels really heavy.'"
    me "'It shouldn't be a problem since I use it every day for repetitive tasks.'"
    me "'Like lifting.'"
    show me well
    me "..."
    me "'It's completely locked in place.'"
    if knife_recieved:
        show me got_it
        me "'Oh.'"
        show knife with dissolve 
        show me smirk
        me "'I have my knife not too far away.'"
        me "'If I'm able to move, I can pick it up and use it.'"
        show me anxiety
        me "'Have to keep that in mind.'"
        hide knife with dissolve 
    call screen screen_pre_main_game
label right_arm:
    show me anxiety
    me "'If I could just move this arm...'"
    me "'I didn't have any plan yet but It had to be useful.'"

    me "'I can only dream about it though, looking at my arm.'"
    call screen screen_pre_main_game
label check_clock:
    scene bg clock with fade
    $ hour = 1
    $ minute = 30
    call screen table_clock2

label check_clock2:
    scene bg sleep 2 with fade
    show me side_eyes
    me "'It's really early.'"
    show me sigh
    me "'No wonder I feel so awake, yet so tired.'"
    call screen screen_pre_main_game
screen table_clock2:

    add "bg clock" at fade_in_bg

    frame:
        background None
        align (0.5, 0.52)
        text "[hour:02d]:[minute:02d]" size 200 color "#00eea7"
    
    textbutton "Go back":
        xanchor 0.5
        yanchor 0.5
        xpos 0.7
        ypos 0.7

        action [Jump("check_clock2")]

label check_phone:
    show me smirk
    me "'I can't move to pick up the phone... but if I could, it might help me.'"
    show me side_eyes
    me "'Maybe the bright screen or a sudden noise would be enough to break this paralysis.'"
    show me stunned
    me "'Or I could use it to call for help.'"
    show me smirk
    me "'I'm joking, haha.'"
    call screen screen_pre_main_game
label sleep_window:
    scene bg window with fade
    show me blank
    me "'Looks the same as usual. Nothing special.'"
    play sound 'audio/sfx_scary.mp3' volume 0.1
    pause 1.0
    scene bg window walk 1 with dissolve
    pause 0.75
    scene bg window walk 2 with dissolve
    pause 0.75
    scene bg window walk 3 with dissolve
    pause 0.75
    scene bg window   with dissolve
    me "...!"
    me "'Who... or what was that?'"
    me "'Is it just my imagination?'"
    me "..."
    me "'I can't move or speak anyway, so I'd better just ignore it.'"
    pause 1.0
    play sound 'audio/sfx_js2.mp3'
    show bg window press at zoomin100
    pause 0.1
    scene bg window press at vpunch

    
    me "'WHAT THE HECK?!'"
    me "'Wait wait wait. This isn't funny. Is this a prank?'"
    me "'Am I draming? That thing doesn't even look like it belongs in reality.'"
    scene bg window with wipedown
    me "'Huh?'"
    me "'Where did it go?'"
    scene bg sleep 2 with fade
    pause 1.0
    play sound 'audio/sfx_window.mp3'
    scene bg get_in 1 with dissolve
    pause 2.0
    scene bg get_in 2 with dissolve
    pause 1.0
    scene bg get_in 3 with dissolve
    pause 1.0
    scene bg get_in 4 with dissolve
    pause 1.0
    scene bg get_in 1 with dissolve
    pause 0.5
    scene bg sleep 2 with dissolve
    pause 0.5

    call screen screen_pre_main_game2

screen screen_pre_main_game2:
    add "bg sleep 2" at fade_in_bg

    if not spd1_clicked:
        imagebutton:
            at fade_in_bg

    
            idle "spd full lean"
            hover "spd full lean hover" 
            
            action [SetVariable("spd1_clicked", True), Jump("talking")]

    
    

label talking:
    play music 'audio/sfx_whisper.mp3'
    scene bg sleep 2 with dissolve
    show me shock 
    show spd joy1 with moveinleft
    spd "Okay. So what do we have here?"
    show spd idle  
    spd "A lovely human!"
    spd "Look. They can't even defend themselves in this state."
    show spd head_talk
    head "Pathetic, pathetic!"

    show spd joy1 with dissolve
    spd "So cute!"
    show spd head_talk
    head "So cute! So cute?"
    me "..."
    show me smirk
    me "'What is this thing?'"
    show me close_eyes
    me "'I must be dreaming right now.'"
    show spd idle with dissolve
    spd "Hello?"
    show me idle
    me "'Uh...'"
    spd "Can you hear us?"
    show spd head_talk
    head "Hear us, hear us!"
    show spd joy2 with dissolve
    spd "..."
    show spd sigh
    spd "I guess they didn't expect 'visitors' like us."
    pause 2.0
    play sound 'audio/sfx_js2.mp3'
    show spd mauling with vpunch
    spd "Listen! We're talking to you, mere lowly mortal!"
    spd "Us! The Unspeakable One!"
    show spd think
    spd "Unspeakable Two, maybe..."
    show spd head_talk
    head "Unspeakable Two!"
    show spd angry  
    spd "Now you know how unfathomable we are. Respect us now, mortal!"
    show spd idle with dissolve
    show me anxiety
    me "'It's because I can't move! Is it my fault?'"
    me "..."
    show me well
    me "'Thinking about it again, it's actually my fault.'"
    show spd think
    spd "Hm."
    show spd idle with dissolve
    spd "A normal human would be falling to their knees and asking for forgiveness by now."
    show spd head_talk 2
    spd "This is weird."
    show spd understand
    spd "Oh!"
    spd "I've heard some humans can sleep with their eyes open. That might be it."
    show spd joy1 with dissolve
    spd "What a blunder."
    show spd head_talk
    head "Blunder, blunder!"
    show spd smirk
    spd "Shut up."
    head "..."
    show me smirk
    me "'Was it just arguing with itself?'"
    show me well
    me "'Truly a sigt to behold.'"
    show spd laugh
    spd "This is too funny!"
    show me what
    me "'Bruh. What am I looking at?'"
    show spd idle  
    spd "What should we do with this mortal then?"
    show me shock
    me "'Shi*!'"
    show spd head_talk
    head "Eat it, eat it!"
    pause 1.0
    show spd shy with dissolve
    spd "We don't know each other yet. Isn't it a bit too fast?"
    pause 1.0
    show spd embarrassed
    spd "Oh, you mean *that* \"eat\"."
    show spd embarrassed head 2
    head "..."
    show me what
    me "..."
    show spd smirk with dissolve
    spd "Hmm~ This mean I can do that with ease."
    show me anxiety
    me "'Are you... serious?'"
    show spd joy1
    spd "Just kidding!"
    show me smirk
    me "'Phew.'"
    spd "I mean.."
    play sound 'audio/sfx_js2.mp3'volume 0.5
    show spd mauling with vpunch
    spd "{b}We{/b} can do that with ease!"
    head "With ease, with ease!"
    play sound "audio/sfx_cough.mp3" volume 0.5
    show me anxiety
    me "*Cough* 'This is really bad. I have to do something.'"
    show spd think
    spd "Oh?"
    show me stunned
    me "'Eh?'"
    me "'Did I just let out a sound?'"
    show me anxiety
    me "'Not sure if that's a good thing or not.'"
    
    show spd idle
    
    spd "Are you listening?"
    show spd joy1 with dissolve
    spd "Was it just in our head?" 
    show spd head_talk
    head "No, it wasn't!"
    show spd idle
    me "'Should I try sending her a signal?'"

    jump menu_sec

menu menu_sec:
    "Try coughing":    
        jump choices2_a
    "Look around":
        jump choices2_b
    "Remain silent":
        jump choices2_c

default spd_known = False

label choices2_a:
    play sound "audio/sfx_cough.mp3" 
    show me angry
    me "*Cough!*"
    show spd consider with dissolve
    spd "Ah-"
    show spd joy1 with dissolve
    spd "You're really awake!"
    show me anxiety
    me "'Why did I do that?!'"
    show spd joy2 with dissolve
    spd "Don't tell me..."
    show spd idle
    spd "Is this sleep paralysis?!"
    show me shock
    me "'It knows?!'"
    show spd joy2
    spd "That means we can do whatever we want with you, and you can't resist. Fufu~"
    head "We want, we want!"
    show me anxiety
    me "'Oh, I'm done for.'"
    me "'I need to get out of here!'"

    play music 'audio/sfx_whisper.mp3'
    scene bg sleep 3 with fade
    $spd_known = True
    $spd_notknown_clicked = False
    call screen main_game

label choices2_b:
    show spd angry 
    spd "Hmph."
    show spd idle with dissolve
    spd "So you hate us."
    spd "You're awake, but you avoid responding!"
    show me anxiety
    me "'How did she know?!'"
    show spd laugh
    spd "You look like you want to say, \"How did she know?!\""
    show spd idle
    spd "It's because of your eye movements."
    show spd head_talk
    head "Idiot human!"
    show me what
    me "'That doesn't explain a thing...'"
    show me anxiety
    me "'This is a dream right? I'll be fine RIGHT?'"
    show spd idle
    spd "If you hate us that much..."
    show spd mauling at zoomin50
    with vpunch
    spd "Then die!!!"

    show spd show_mouth with dissolve 
    pause 1.0
    jump die

label choices2_c:
    show spd idle with dissolve
    spd "So that was just sleep-talking?"
    show me idle
    me "..."
    show spd think
    spd "This mortal could have sleep apnea. They should go see a doctor!"
    me "..."
    show me what
    me "'What is it talking about?'"
    show spd joy1
    spd "That means we can stick to the plan, I guess."
    show me well
    me "'Oh, I forgot I'm still dead.'"
    show spd think with dissolve
    spd "Hmm. It'd take about half an hour."
    show spd joy1
    spd "Since this human's still unconcious, this much time is nothing!"
    show me got_it
    me "'This is it!'"
    show spd idle
    show me anxiety
    me "'Now it's time to think.'"
    me "'Just in case, this isn't a dream.'"
    me "'Sleep paralysis usually take only about 20 minutes before it wears off which mean I still have about 10 minutes left.'"
    show me side_eyes
    me "'I can concentrate on the {b}actions{/b} I want to perform before I do so when the time ran out I can move flawlessly!'"
    me "'Though with my human reflex, I believe I can only do {b}two{/b} things to do in critical situation."
    show me smirk
    me "'I must be careful to choose which actions that could really help me out.'"
    hide spd idle with moveoutright
    pause 1.0
    show me serious
    me "'Screw it, we ball.'"
    play music 'audio/music_ending.mp3' volume 0.5
    scene bg sleep 3 with fade
    $ attempt_enable = True
    call screen main_game






#Variables2

default check_clock_clicked = False

default spd_known_clicked = False
default spd_notknown_clicked = False

default spd_known_2 = False

default attempt = 0
default attempt_enable = False
define max_attempt = 6

default swift_chosen_action = None

default attempt_phone = 0
default attempt_window = 0
default attempt_right = 0
default attempt_left = 0

screen attempt_status:
    if attempt_enable:
        frame:
            align (0.98, 0.02)
            background None
            has vbox:
                spacing 10
                text "{b}Attempt Count:{/b}" size 24 color "#FFFFFF" outlines [(2, "#000000")]
                bar value attempt range max_attempt xmaximum 200




screen main_game:
    add "bg sleep 3" at fade_in_bg

    # sleep clock (Left)
    imagebutton:
        xanchor 0.5
        yanchor 1.0
        pos (1831, 1055) 
        idle "idle sleep clock"
        hover "hover sleep clock"
        action [Hide("display_text"), Jump("check_clock_main_game")]
        hovered Show("display_text", displayText="the clock")
        unhovered Hide("display_text")

    # window (Right)
    if not attempt_window >= 2 :
        imagebutton:
            xanchor 0.5
            yanchor 1.0
            pos (206, 641) 
            idle "idle sleep window"
            hover "hover sleep window"
            action [Hide("display_text"), Jump("sleep_window_2")]
            hovered Show("display_text", displayText="the window")
            unhovered Hide("display_text")

    # left arm (Center)
    if not attempt_left >= 2 :
        imagebutton:
            xanchor 0.5
            yanchor 1.0
            pos (418, 1080) 
            idle "left arm"
            hover "hover grab"
            action [Hide("display_text"), Jump("left_arm_2")]
            hovered Show("display_text", displayText="left arm")
            unhovered Hide("display_text")

    # right arm (Center)
    if not attempt_right >= 2 :
        imagebutton:
            xanchor 0.5
            yanchor 1.0
            pos (1520, 1080) 
            idle "right arm"
            hover "hover grab"
            action [Hide("display_text"), Jump("right_arm_2")]
            hovered Show("display_text", displayText="right arm")
            unhovered Hide("display_text")

    # phone (Left)
    if not attempt_phone >= 2 :
        imagebutton:
            xanchor 0.5
            yanchor 1.0
            pos (1698, 940) 
            idle "idle sleep phone" 
            hover "hover sleep phone"
            action [Hide("display_text"), Jump("check_phone_2")]
            hovered Show("display_text", displayText="the phone")
            unhovered Hide("display_text")

    if not spd_known and not spd_known_clicked:
        if attempt < 2:
            imagebutton:
                at fade_in_bg
                xanchor 0.5
                yanchor 1.0
                pos (1631, 811) 
                idle "spd full stand"
                action [Hide("display_text"), Jump("label_spd_notknown")]
                hovered Show("display_text", displayText="Spd")
                unhovered Hide("display_text")
        if attempt == 2 or attempt == 3:
            imagebutton:
                at fade_in_bg
                xanchor 0.5
                yanchor 1.0
                pos (1060, 720) 
                idle "spd full bend"
                action [Hide("display_text"), Jump("label_spd_notknown")]
                hovered Show("display_text", displayText="Spd")
                unhovered Hide("display_text")
        if attempt == 4 or attempt == 5:
            imagebutton:
                    at fade_in_bg
                    xanchor 0.5
                    yanchor 1.0
                    pos (960, 1060) 
                    idle "spd full lay"
                    action [Hide("display_text"), Jump("label_spd_notknown")]
                    hovered Show("display_text", displayText="Spd")
                    unhovered Hide("display_text")



        
    if spd_known and not spd_notknown_clicked:

        imagebutton:
            at fade_in_bg
            xanchor 0.5
            yanchor 1.0
            pos (982, 1080) 
            idle "spd full top"
            hover "spd full top hover"
            action [Jump("label_spd_known")]
            
         





label check_clock_main_game:
    if look_left:
        jump get_caught

    scene bg clock with fade
    call screen table_clock3
    call screen main_game

label check_phone_2:
    if look_left:
        jump get_caught
    
    if attempt_phone == 0:
        show me idle
        me "'I can use it to call for help'"
        show me smirk
        me "'I need to move...'"
    else:
        show me anxiety
        me "'I need to aim at the  {b}phone{/b} one more time before I can reach at it.'"

    if not spd_known and not spd_known_clicked:
        

        call screen spd_not_know_choice("Do you want to concentrate on the phone?", "attempt_phone")
        if _return:
            $ attempt += 1
            $ minute += 5
            $ drag_count = 0

            label phone_struggle_loop:
                if drag_count < 3:
                    call screen drag_hand
                    if _return == "Reaching":
                        $ drag_count += 1
                        $ renpy.notify("Concentrate... " + str(drag_count) + "/3")
                        jump phone_struggle_loop

            if attempt_phone == 1:
                show me smirk
                me "'I should call the emergency numbers.'"
                show me anxiety
                me "'If I remember correctly, it should be 911.'"
                me "'Haa. I can do this.'"
            else:
                show me close_eyes
                me "'I'm ready! I could grab it if I want.'"
                show me idle
                me "'I'll strike when she least expects.'"
            jump spdtalk_6_attempt


    call screen main_game

label sleep_window_2:
    if look_right:
        jump get_caught

    if attempt_window == 0:
        show me got_it
        me "'This window is wide enough for this monster to get in.'"
        show me well
        me "'That mean I can escape from there!'"
    else:
        show me sigh
        me "'I need to aim at the {b}window{/b} one more time before I'm confident to escape.'"

    if not spd_known and not spd_known_clicked:
        
        call screen spd_not_know_choice("Do you want to concentrate on the window?", "attempt_window")
        if _return:
            $ attempt += 1
            $ minute += 5
            $ drag_count = 0

            label window_struggle_loop:
                if drag_count < 3:
                    call screen drag_hand
                    if _return == "Reaching":
                        $ drag_count += 1
                        $ renpy.notify("Concentrate... " + str(drag_count) + "/3")
                        jump window_struggle_loop

            if attempt_window == 1:
                show me idle
                me "'I need to pull the latch up first, got it.'"
            else:
                show me talk
                me "'I'm ready! I can escape if I want.'"
                me "'I'll slip out when she least expects.'"
            jump spdtalk_6_attempt

    call screen main_game


label left_arm_2:
    if look_center:
        jump get_caught

    if attempt_left == 0:
        show me anxiety
        me "'I need to move my left arm.'"
        me "'Maybe to push it away together with right arm.'"
        
        if knife_recieved:
            show me got_it
            me "'Oh! I almost forgot.'"
            show me smirk
            me "'I can pick up the knife and stab it!'"
        else:
            show me sigh
            me "'*Sigh* If only I have something to defend myself.'"
    else:
        show me idle
        me "'I need to focus on my {b}left arm{/b} one more time before before I can insert power into it.'"

    if not spd_known and not spd_known_clicked:
        
        call screen spd_not_know_choice("Do you want to concentrate on your left arm?", "attempt_left")
        
        if _return:
            $ attempt += 1
            $ minute += 5
            $ drag_count = 0 

            label left_arm_struggle_loop:
                if drag_count < 3:
                    call screen drag_hand
                    if _return == "Reaching":
                        $ drag_count += 1
                        $ renpy.notify("Concentrate... " + str(drag_count) + "/3")
                        jump left_arm_struggle_loop 
            
            if attempt_left == 1:
                show me sigh
                me "'My left hand is twiching! That's a progress.'"
                if knife_recieved:
                    show me serious
                    me "'Can't wait to teach it a reason!'"
            else:
                show me anxiety
                me "'I'm ready! I have full control of my left arm.'"
            jump spdtalk_6_attempt

    call screen main_game


label right_arm_2:
    if look_center:
        jump get_caught

    if attempt_right == 0:
        show me anxiety
        me "'I can use my right arm to push her out.'"
        me "'Not sure if it will work.'"
    else:
        show me idle
        me "'I need to focus on my {b}right arm{/b} one more time before before I can insert power into it.'"

    if not spd_known and not spd_known_clicked:
     
        call screen spd_not_know_choice("Do you want to concentrate on your right arm?", "attempt_right")
        if _return:
            $ attempt += 1
            $ minute += 5
            $ drag_count = 0

            label right_arm_struggle_loop:
                if drag_count < 3:
                    call screen drag_hand
                    if _return == "Reaching":
                        $ drag_count += 1
                        $ renpy.notify("Concentrate... " + str(drag_count) + "/3")
                        jump right_arm_struggle_loop

            if attempt_right == 1:
                show me smirk
                me "'I feel like I can move my fingers.'"
            else:
                show me smirk
                me "'I'm ready! My right arm is free to strike.'"
            jump spdtalk_6_attempt

    call screen main_game

label spdtalk_6_attempt:
    scene bg sleep 3 with fade

    # attempt1-2 = Lab
    if attempt == 1:
        show spd smirk with moveinright
        spd "Now that we're finally free... and our little mortal is still refusing to respond."
        show spd idle
        spd "Should we vent a bit to pass the time? Is that a good idea?" 
        show spd head_talk
        head "It is! It is!" 
        show me smirk
        me "'This is actually getting interesting.'" 
        show spd think
        spd "Let me think... Oh, I remember!"
        show spd angry
        spd "I truly disgust those bastards!" 
        spd "They kept us trapped for... how long has it been, exactly?"
        show spd smirk
        spd "Never mind. It doesn't matter."
        spd "The point is, they deserve to be tormented over and over again."
        show spd head_talk
        head "Truly! We hate them!"
        show spd think
        spd "But... I suppose I should thank that woman."
        spd "Without her, we never would have had a chance like this." 
        show spd idle
        spd "Otherwise, those humans would have kept us caged like livestock."
        me "'You look more like an octopus, honestly.'"
        show spd think
        spd "Humans... they're usually so dumb, yet they're surprisingly good when it come to commit a sin."
        show spd smirk
        spd "What an irony."
        pause 1.0
        show spd joy1 with dissolve
        spd "At least this outfit I got is adorable."
        show spd laugh
        spd "Then again, I'd rock anything."
        show spd joy1
        spd "And most importantly..."
        show spd joy2 with dissolve
        spd "No one can stop me now."
        show me serious
        me "..."

    if attempt == 2:
        show spd think with dissolve
        spd "When we think about it... why did she escape, really?"
        spd "That lady."
        show spd consider
        spd "Could it be... that she got what she want?"
        show spd head_talk
        head "Could be!"
        show spd think
        spd "Without her we wouldn't be here."
        spd "At all."
        show spd smirk
        spd "But enough of the serious talk."
        spd "The food back there was quite delicious, wasn't it?"
        show spd head_talk
        head "Right!"
        show me idle
        me "'I didn't think they had a human side...'"
        show spd think
        spd "Like that one prisoner's brain. And then that lovely spinal cord."
        show me what
        me "'I take it back.'"
        show spd joy1
        spd "Oh! That one was also tasty~"
        show spd think
        spd "What was it called?"
        show spd head_talk
        head "Apple!"
        show spd understand
        spd "Ah, an apple!"
        show spd joy1
        spd "We're so clever!"
        show spd sad with dissolve
        spd "Pity... we might never taste one again."
        head "Pity..."
        show spd idle
        spd "However!"
        show spd open_head
        spd "We're going to sink our teeth into something far more exquisite very soon."
        show spd head_talk 1
        head "*Gulp*"
        show me shock
        me "'*Gulp*'"

    #attempt 3 = dream
    if attempt == 3:
        show spd joy1
        spd "If you're listening, don't afraid too much."
        spd "We didn't plan on devouring your flesh."
        show spd joy2 with dissolve
        spd "Yet."
        show spd joy1
        spd "Regardless!"
        spd "What we really want.. is to eat your {b}dreams{/b}." 
        show me stunned
        me "'My... my dreams? Wait, did she say \"yet\"!?'"
        show spd think
        spd "The humans those bastards fed us were all dead inside."
        spd "No spark in their eyes whatsoever."
        show spd angry
        spd "They tasted of nothing but ash and bone."
        spd "Completely ruined my tastebud for a week."
        show spd joy1
        spd "I hope this one will be different!"
        show spd smirk
        spd "Prying open a mind takes a bit of work, of course." 
        spd "I hope it's worth the effort."
        show spd mauling
        spd "Otherwise... we'll just have to settle for your flesh instead." 

    #attempt 4-5 = their details
    if attempt == 4:
        show spd idle with dissolve
        spd "Only 10 minutes left before we can do the thing!"
        show spd think
        spd "Really hard to believe you haven't move since the begining."
        play sound 'audio/sfx_js2.mp3'volume 0.5
        show spd mauling with vpunch
        spd "Have you?"
        show spd laugh
        spd "We actually don't care though!"
        spd "Even if you're listening right now, your mortal body still useless."
        show spd idle
        spd "You can't do anything anyway."
        show spd think
        spd "When I was young, I also can't do anything also."
        show spd laugh
        spd "This actually feel weirdly nostalgia. "
    
    if attempt == 5:
        show spd think
        spd "I used to be lonely."
        show spd joy1
        spd "Now I'm not, thank to another me!"
        show spd head_talk 2
        head "..."
        show spd joy1
        spd "..."
        show spd idle
        spd "When we get into your mind, we'll definitely see more mesmerizing stuffs."
        show spd joy1
        spd "Can't wait any longer!"
    #attempt 6
    if attempt == 6:
        show spd joy1 with dissolve
        spd "Well well well~ This is it."
        show spd idle with dissolve
        spd "We've found the way into your mind."
        show spd mauling with vpunch
        spd "Let's see what kind of person you really are!"
        show me anxiety
        me "'Should I take an action now?'"
        stop music
        $ attempt_enable = False
        menu:
            "Take Action":
                scene bg sleep 3 with dissolve
                $ choose_action = 0
                $ phone_pick = False
                $ left_pick = False
                $ knife_pick = False
                $ right_pick = False
                $ window_pick = False

                label two_action_combine_loop:
                    if choose_action < 2:
                        call screen two_action_combine
                        
                        if _return == "phone":
                            $ choose_action += 1
                            $ renpy.notify("Choose " + str(choose_action) + "/2 action")
                            $ phone_pick = True
                            jump two_action_combine_loop

                        if _return == "left":
                            $ choose_action += 1
                            $ renpy.notify("Choose " + str(choose_action) + "/2 action")
                            $ left_pick = True
                            jump two_action_combine_loop
        
                        if _return == "knife":
                            $ choose_action += 1
                            $ renpy.notify("Choose " + str(choose_action) + "/2 action")
                            $ knife_pick = True
                            jump two_action_combine_loop

                        if _return == "right":
                            $ choose_action += 1
                            $ renpy.notify("Choose " + str(choose_action) + "/2 action")
                            $ right_pick = True
                            jump two_action_combine_loop
                        
                        if _return == "window":
                            $ choose_action += 1
                            $ renpy.notify("Choose " + str(choose_action) + "/2 action")
                            $ window_pick = True
                            jump two_action_combine_loop
                    
                    else:
                        if phone_pick and window_pick:
                            jump label_phone_and_window
                        elif left_pick and right_pick:
                            jump label_left_right
                        elif knife_pick and window_pick:
                            jump label_knife_window
                        elif knife_pick and phone_pick:
                            jump label_knife_phone
                        else:
                            show spd angry with dissolve
                            spd "What are you doing? We gave you half an hour and this is what you got?"
                            
                            spd "Disappointed."
                            play sound 'audio/sfx_caught.mp3' volume 0.5
                            scene spd catch 1 with fade
                            me "I- I can explain!"
                            spd "What? You can?"
                            spd "We don't think you can."
                            scene spd catch 2 with dissolve
                            spd "Shut up already."
                            jump die2

            "Do nothing":
                show me idle
                me "'This is most likely just my mind playing tricks on me.'"
                me "'No need to act rashly.'"
                show me close_eyes
                me "'Just stay calm...'"

                jump dream_session

    scene bg sleep 3 with dissolve
    call screen main_game


# Variables pick
default choose_action = 0
default phone_pick = False
default left_pick = False
default knife_pick = False
default right_pick = False
default window_pick = False


screen two_action_combine:
    frame:
        xalign 0.5
        yalign 0.5
        xysize (1505, 1005)
        background Solid("#a0a0a0") 
        
        frame:
            xalign 0.5
            yalign 0.5
            xysize (1500, 1000)
            background Solid("#050505") 
            padding (60, 40)

            vbox:
                xalign 0.5
                ypos 50
                spacing 20
                
                text "Pick the {b}action{/b} you want to do." size 45 color "#ffffff" xalign 0.5 text_align 0.5
                text "[choose_action] / 2" size 30 color "#ff0000" xalign 0.5 bold True

            draggroup:
                xfill True
                yfill True
                
                if attempt_phone == 2 and not phone_pick:
                    drag:
                        drag_name "phone"
                        child Text("USE YOUR PHONE", size=40, color="#ffffff", bold=True, outlines=[(2, "#000")])
                        xpos 0.5     
                        xanchor 0.5  
                        ypos 0.75
                        yanchor 0.5
                        draggable False
                        droppable True
                        
                if attempt_left == 2 and not left_pick:
                    drag:
                        drag_name "left"
                        child Text("USE YOUR LEFT ARM", size=40, color="#ffffff", bold=True, outlines=[(2, "#000")])
                        xpos 0.2    
                        xanchor 0.5
                        ypos 0.55
                        yanchor 0.5
                        draggable False
                        droppable True
                        
                if attempt_left == 2 and knife_recieved and not knife_pick:
                    drag:
                        drag_name "knife"
                        child Text("USE YOUR KNIFE", size=40, color="#ffffff", bold=True, outlines=[(2, "#000")])
                        xpos 0.2    
                        xanchor 0.5
                        ypos 0.35
                        yanchor 0.5
                        draggable False
                        droppable True
                        
                if attempt_right == 2 and not right_pick:
                    drag:
                        drag_name "right" 
                        child Text("USE YOUR RIGHT ARM", size=40, color="#ffffff", bold=True, outlines=[(2, "#000")])
                        xpos 0.8    
                        xanchor 0.5
                        ypos 0.55
                        yanchor 0.5
                        draggable False
                        droppable True
                                   
                if attempt_window == 2 and not window_pick:
                    drag:
                        drag_name "window" 
                        child Text("ESCAPE THROUGH WINDOW", size=40, color="#ffffff", bold=True, outlines=[(2, "#000")])
                        xpos 0.8    
                        xanchor 0.5
                        ypos 0.35
                        yanchor 0.5
                        draggable False
                        droppable True

            
                drag:
                    drag_name "obj2"
                    child "hover grab" 
                    xpos 0.5 xanchor 0.5 ypos 0.55 yanchor 0.5
                    draggable True
                    dragged hand_dragged
            
            if persistent.two_actions_unlock >= 3:
                imagebutton:
                            idle Text("Unlock all options.", size=20, color="#ffffff", underline=True)
                            hover Text("Unlock all options.", size=20, color="#ff0000", underline=True)
                            action [SetVariable("attempt_phone", 2)
                            , SetVariable("attempt_phone", 2)
                            , SetVariable("attempt_left", 2)
                            , SetVariable("attempt_right", 2)
                            , SetVariable("attempt_window", 2), Hide("display_text"), Play("sound", "sfx_yes.mp3")]
                            hovered Show("display_text", displayText="You've unlocked at least 3 scenarios.\n {i}Click to unlock all options.{/i}")
                            unhovered Hide("display_text")
                

   
default persistent.two_actions_unlock = 0

#ending with two action
label label_phone_and_window:
    
    show spd shock with vpunch
    show me serious
    me "Haa!"
    show me smirk
    me "'Yes, I got the phone!'"
    me "'Calling isn't fast enough, I have to-'"
    "You throw the phone out of the window with all your strength, hoping the sound of breaking glass or the GPS signal will draw attention."
    show spd consider with dissolve
    spd "Oh? What's that?"
    show me anxiety
    me "'Please, anyone help me.'"
    
    show spd laugh
    spd "You think someone is coming just because you threw a phone out the window? Ridiculous!"
    head "Ridiculous!"
    
    show spd smirk
    spd "Who did you expect to come, a nearby neighbor you've never talked too?"
    show spd idle
    spd "Actually, No one will ever come."
    show spd joy1
    spd "You're a nobody."
    spd "Always has been."
    show spd think
    spd "Even if the police came, do you think they'd find you in time?"
    show me stunned
    me "I..."

    me "'What make it's hard to swallow is she's actually true.'"
    show spd idle with dissolve
    show me scared
    me "'How did I forget that...'"
    pause 1.0
    show me accept
    me "I surrender. You can eat me whenever you want, I don't care"
    "You close your eyes."
    scene black with fade
    show me blank
    me "..."
    spd "That's not a bad plan."
    spd "That's actually really smart!"
    head "Smart smart!"
    scene bg sleep 3 with fade
    show spd idle
    show me smirk
    me "'Eh.'"
    show spd joy1

    spd "But I can't let you go."
    show spd joy2 with dissolve
    spd "Not at the moment..."

    $ persistent.two_actions_unlock += 1

    jump dream_session

label label_left_right:
    show spd shock
    "In a moment of pure adrenaline, you lunge forward. You use both arms to push her back."
    "But your momentum carries you forward, pinning her against the bed."
    scene bg pin with fade
    show spd pin shock at zoomout300
    pause 0.5
    show hand pin at zoomout300
    spd "Wha-!?"
    show spd pin idle with dissolve
    spd "You're stronger than you look."
    show spd pin talk
    head "Strong human!"
    show me anxiety
    me "I-I've got you now! Don't move!"
    show spd pin talk 1
    spd "Oh no~ What're you doing~"
    show spd pin look left with dissolve
    spd "We're only helpless lady."
    show spd pin look up with dissolve
    spd "You're holding me down, but your heart is beating so fast I can hear it from here."
    show me serious
    me "You're Monster!"
    spd "Anyone who sees this knows who's the 'real' monster fufu~ "
    show spd pin look down with dissolve
    spd "What's your plan, mortal?~"
    show me anxiety
    me "'What should I do?'"
    show spd pin idle with dissolve
    spd "Are you trying to stop me... or are you just enjoying the view?"

    menu menu_pin:
        "Get up":
            "You slowly loosen your grip and pull away."
            scene bg sleep 3 with fade
            
            show spd consider
            spd "Oh? You're actually letting me go?"
            
            show spd idle
            show me smirk
            me "Augh- I- I'm sorry!"
            
            show spd think
            spd "And here we thought you were going to do something truly heinous."
            show me anxiety
            me "'I couldn't bring myself to do it...'"
            me "'Besides, there's no way I could actually win against her anyway.'"

            show spd shy with dissolve
            spd "That would have been... troublesome."
            show me stunned
            me "Huh?"
            
            show spd shh
            spd "Ahem- I suppose you still have some common sense left."
            
            show spd idle
            spd "That's just one more reason for me to 'explore' your mind."
            show me smirk
            me "What... what's going to happen to me?"
            
            show spd joy1
            spd "Don't worry. It'll be over before you know it..."
            jump dream_session

        "Attack":
            if knife_recieved:
                hide hand pin with dissolve
                play sound 'audio/sfx_knife.mp3'
                "You pull out the knife and strike."
                play sound 'audio/sfx_js2.mp3'
                show bg red
                pause 0.1
                show black 
                pause 0.1
                scene bg pin
                show spd pin shock with vpunch
                spd "?!"
                pause 1.0
                show spd pin idle with dissolve
                pause 1.0
                show spd_hand knife_move at moveinbuttom
                spd "Did you forget? I have four arms."
                show me serious
                me "'She caught the blade with her other hands?! I completely forgot she had extra limbs... I'm doomed.'"
                show spd_hand knife
                show spd pin look left with dissolve
                spd "I'm not even angry. Just... disappointed."
                show spd_hand knife_move
                show spd pin idle with dissolve
                spd "Now, it's my turn."
                show me scared
                me "Wha-"
                
                scene bg sleep 3 with fade
                pause 1.0
                show spd full sit with dissolve
                pause 1.0
                show spd full lay center with dissolve
                "She easily overpowers you and slams you back onto the mattress."
                
                me "I... can't... move..."
                me "'This is bad, it's much stronger than me.'"
                play sound 'audio/sfx_caught.mp3' volume 0.5
                scene spd catch 1 with fade
                
                spd "Well, well, well. How the tables have turned."
                
                me "Please-"
                scene spd catch 2 with dissolve
                
                spd "Let me show you what a 'real' monster looks like."
                show spd jump_scare at zoomin100
                
                show blood1 at zoomin200
                pause 0.1
                show blood2 at zoomin100
                pause 1.0
                
                scene black with fade
                pause 0.5
                "You feel a crushing pressure, but the world has gone dark."
                "The only thing you can taste is the metallic taste at tip the your tongue."
                "Your consciousness slowly slips away into the cold."
                scene bg ending 4 with fade
                play music "audio/music_ending.mp3" volume 0.5
                pause 2.0
                $ persistent.ending4 = True
                $ persistent.two_actions_unlock += 1

                "Ending 4 - {b}Another Pair{/b}"
                "You should have remembered, four arms are always better than two."
                
                return

            else:
                "You squeeze her wrists even harder, trying to overpower her."
                show me serious
                me "'It's not working!'"
                me "'I can't hurt her with my bare hands.'"
                show me anxiety
                me "'If only I had a weapon, I might have stood a chance...'"
                
                show spd pin look down with dissolve
                spd "Is that all you've got, mortal?~"
                show me angry
                me "Tck-"

                "Exhausted, you loosen your grip."
                
                scene bg sleep 3 with fade
                show spd smirk with dissolve
                spd "Oh! So you've decided to behave?"
                
                show spd idle
                show me anxiety
                me "It... it was an accident."
                
                show spd joy2
                spd "Really now?"
                spd "I thought you were trying to be naughty."
                show me stunned
                me "Haaa?!"
                show spd laugh
                spd "We're kidding!"
                show me smirk
                me "'This girl is unbelievable...'"

                show spd idle with dissolve
                spd "We'll stick to the original plan, then."
                show me stunned
                me "Wait, what plan?"
                
                show spd shh
                spd "You should know by now. I've explained it enough times."
                
                show spd idle
                spd "Now... be a good boy and close your eyes."
                $ persistent.two_actions_unlock += 1
                jump dream_session
            
            
        

   

label label_knife_window:
    "You grab the knife and stab her in the chest."
    play sound 'audio/sfx_js2.mp3'
    show bg red
    pause 0.1
    show black 
    pause 0.1
    scene bg sleep 3
    show spd stabbed1 at zoomout300
    with vpunch
    pause 0.1
    show blood1 black at zoomin200
    pause 0.1
    show blood2 black at zoomin100
    pause 1.0 
    hide blood1 with dissolve
    hide blood2 with dissolve
    spd "Asck!"
    head "Gssssss!"
    show spd stabbed2 with dissolve
    me "'This is my chance!'"
    "You run straight at the window."
    scene bg window with dissolve
    spd " COME BACK AND I MIGHT FORGIVE YOU-"
    show me smirk
    me "Who'd be that dumb?"
    menu menu_escape:
        "Stay":
            "You walk back to the bed."

            scene bg sleep 3 with fade
            show spd shock with dissolve
            show me idle
            me "Yep, that's me."
            spd "Oh!"
            show spd shy with dissolve
            spd "That really caught me off guard."
            show me side_eyes
            me "You look lonely, I can't just leave you alone right?"
            show spd sigh
            spd "*Sigh* We've never thought you'd actully listen."
            show spd embarrassed head 1
            spd "Beside, we can't be alone. You see..."
            show spd head_talk
            head "Alone, alone!"
            show me talk
            me "Umm... Should I leave both of you, then?"
            me "I'm fine with that."
            show spd idle
            spd "Not really."
            show spd mauling with vpunch
            spd "We're craving for blood now.."
            show me scared
            me "?!!"
            show spd laugh
            spd "We're joking!"
            show spd idle
            spd "We can't leave you alone yet."
            show spd joy1
            spd "Be a good boy and shut your eyes."
            $ persistent.two_actions_unlock += 1
            jump dream_session

        "Run away":
            scene black with fade
    
            "You throw yourself out of the window."
            play sound 'audio/sfx_window.mp3'
            spd "Come bac..."
            scene run with fade
            play music 'audio/sfx_run.mp3' volume 0.03

            "You look forwand and run without knowing what the destination is."
            "The sound of everything start fading away."
            show me blank
            me "I- *huff* can't- *huff* look back- *huff*."
            "You run, run, and run."
            "You know that this is the only way to survive."
            "Strangely, you feel empty."
            me "'Is this the right choice?'"
    
            scene bg ending 5 with fade
            play music "audio/music_ending.mp3" volume 0.5
            pause 2.0
            $ persistent.two_actions_unlock += 1
            $ persistent.ending5 = True
            "Ending 5 - {b}Run away{/b}"
            "You ran as far as you could. For now, you are safe."
            
            return


label label_knife_phone:
    show knife with dissolve
    play sound 'audio/sfx_knife.mp3'
    "You insert the knife directly into the monster and pick uo the phone."
    play sound 'audio/sfx_js2.mp3'
    show bg red
    pause 0.1
    show black 
    pause 0.1
    scene bg sleep 3
    show spd stabbed1 at zoomout300
    with vpunch
    pause 0.1
    show blood1 black at zoomin200
    pause 0.1
    show blood2 black at zoomin100
    pause 1.0 
    hide blood1 with dissolve
    hide blood2 with dissolve
    spd "Ouch!"
    show spd stabbed2
    spd "You stabbed us, really?!"
    show me serious
    me "Stay back! I'm calling for help!"
    me "I'm sorry but It can't help!"
    show me anxiety
    me "'Forget about her, Which number should I call?'"

    $ phone_number = ""
    call screen phone_keypad
    
    if phone_number == "911":
        jump label_9111
    elif phone_number == "4747":
        jump label_4747
    else:

        "You make a call."
        "But no one picked it up."
        show me anxiety
        me "Please some one, pick it up!"
        show spd stabbed black with dissolve
        pause 0.5
        show spd idle with dissolve
        spd "It seems like you lost your only chance."
       
        show spd angry
        spd "That's pathetic."
        show me smirk
        me "Can we... Can we talk?"
        show spd joy1
        spd "No! But we're merciful so it'll be quick."
        scene spd catch 2 with fade
        spd "Now clench your teech!"
        jump die2

label label_9111:
    "You dial the number with trembling fingers. The line clicks open..."

    police "911, what is your emergency?"
    show me anxiety 1
    me "Yes! Finally!"
    show me anxiety
    me "Help! Please, help me! There's... there's a monster in my house!"
    me "Please, you have to-"
    police "Sir, calm down. What are you talking ab-"
    
    "Suddenly, the phone is snatched right out of your hands."
    show spd stabbed black with dissolve
    pause 0.5
    show spd with_phone1 with dissolve
    spd "Sorry about that, officer~ It was just a prank call. My friend has had a bit too much to drink."
    show me shock
    me "No! Give it back!"
    show spd with_phone2
    spd "And what if I don't?"
    spd "I'm hanging up now. Goodbye~"
    spd "*Click*"
    show spd angry
    spd "Now... what should we do with you?"
    show me serious
    me "*Gulp*"
    show spd sigh
    spd "Since you actually made the call, the authorities will be here soon."
    show spd shh
    spd "You've left me with no other choice."
    show me scared
    me "No, no, no! Get away from me! Stay back!"
    show spd open_head with dissolve
    spd "It's too late for that."
    window hide
    play sound 'audio/sfx_js.mp3'
    show spd jump_scare at zoomin100
    with vpunch
    pause 0.1
    show blood1 at zoomin200
    pause 0.1
    show blood2 at zoomin100
    pause 1.0
    scene black with fade
    pause 1.0
    scene bg door with fade
    "The police arrive hours later. "
    play sound 'audio/sfx_door.mp3'
    scene bg door police with dissolve
    "They open the bedroom door wide open and walk slowly into it."
    scene bg found_corpse with fade
    pause 0.5
    "A strong rotten smell hit their noses once they pull out the blanket."
    "They find what's left of you smear all across the bed."
    
    scene bg spd corner with fade
    police "Yes, we have a murder here!"
    police "We need backup."
    
    police "What do you mean, we can't? This is serious!"
    scene bg spd corner 2 with dissolve
    pause 0.5
    police "Huh? Retreat? What do you mean-"

    scene bg ending 6 with fade
    play music "audio/music_ending.mp3" volume 0.5
    pause 2.0
    $ persistent.two_actions_unlock += 1
    $ persistent.ending6 = True
    "Ending 6 - {b}Slaughter{/b}"
    "You died. "
    "But you're not alone."
    
    
    return

label label_4747:
    "You dial the number with trembling fingers. The line clicks open immediately..."
    
    mysterious "This is the hotline for unusual incidents related to the recent facility explosion."
    mysterious "State your emergency. How can we help you?"
    show me anxiety
    me "'Yes! Finally!'"
    me "I... I think I saw a monster!"
    me "Maybe I'm just hallucinating, but it looks so real..."
    show me serious
    me "You won't believe me, but it's like a... a black blob?"
    
    mysterious "Location confirmed. We are sending a team immediately. Get out of there now!"
    show spd stabbed black with dissolve
    pause 0.5
    show spd shock at zoomin100
    spd "That voice... those people..."
    
    show spd angry
    spd "You shouldn't have done that. Now I have to finish this quickly!"
    
    show spd with_phone2 with vpunch
    
    "She snatches the phone out of your hand."
    show me shock
    me "Augh-!"
    
    show spd mauling
    spd "How did you get that number?!"
    
    show spd mauling with vpunch
    show me anxiety
    me "What do you even mean?!"
    spd "Whatever. It doesn't matter now. Die!"
    play soud 'audio/sfx_js.mp3'
    show spd jump_scare at zoomin100
    show me dizzy
    me "AHHHHHHHHHHHHHHHHHHH!"
    scene black with dissolve
    pause 1.5
    scene bg door with fade
    
    "Heavy boots thud against the porch. Flashlights cut through the darkness of the windows."
    play sound 'audio/sfx_door.mp3'
    scene bg door hazard with dissolve
    "But the boots are too late to save the man inside."
    
    scene bg found_corpse with fade
    pause 0.5
    "By the time the team breaks down the door, only a fresh bloodstain remains."
    
    mysterious1 "Look at this, sir!"
    
    mysterious2 "Damn it! We were too late."
    
    mysterious1 "What are our orders, sir?"
    
    mysterious2 "Secure the area and find that creature. It can't have gone far."
    mysterious2 "And remember, no one can ever know what happened here."
    
    mysterious1 "Yes, Chief!"
    
    scene bg ending 7 with fade
    play music "audio/music_ending.mp3" volume 0.5
    pause 2.0
    $ persistent.two_actions_unlock += 1
    $ persistent.ending7 = True
    "Ending 7 - {b}Missing Person{/b}"
    "Now you're just another face on a missing person's poster. No one knows where you went, and eventually, no one will care."
    
    
    return

default phone_number = ""
screen phone_keypad():
    modal True
    zorder 100
    add "screen phone" at fade_in_bg

    vbox:
        align (0.5, 0.35)
        spacing 20
        text "[phone_number]" size 70 xalign 0.5 color "#fff"

    textbutton "1":
        pos (795, 630) 
        xanchor 0.5
        yanchor 0.5
        text_size 40
        text_idle_color "#fff"
        text_hover_color "#aaa"
        action SetVariable("phone_number", phone_number + "1")

    textbutton "2":
        pos (960, 630) 
        xanchor 0.5
        yanchor 0.5
        text_size 40
        text_idle_color "#fff"
        text_hover_color "#aaa"
        action SetVariable("phone_number", phone_number + "2")

    textbutton "3":
        pos (1125, 630) 
        xanchor 0.5
        yanchor 0.5
        text_size 40
        text_idle_color "#fff"
        text_hover_color "#aaa"
        action SetVariable("phone_number", phone_number + "3")

    textbutton "4":
        pos (795, 720) 
        xanchor 0.5
        yanchor 0.5
        text_size 40
        text_idle_color "#fff"
        text_hover_color "#aaa"
        action SetVariable("phone_number", phone_number + "4")

    textbutton "5":
        pos (960, 720) 
        xanchor 0.5
        yanchor 0.5
        text_size 40
        text_idle_color "#fff"
        text_hover_color "#aaa"
        action SetVariable("phone_number", phone_number + "5")

    textbutton "6":
        pos (1125, 720) 
        xanchor 0.5
        yanchor 0.5
        text_size 40
        text_idle_color "#fff"
        text_hover_color "#aaa"
        action SetVariable("phone_number", phone_number + "6")

    textbutton "7":
        pos (795, 810) 
        xanchor 0.5
        yanchor 0.5
        text_size 40
        text_idle_color "#fff"
        text_hover_color "#aaa"
        action SetVariable("phone_number", phone_number + "7")

    textbutton "8":
        pos (960, 810) 
        xanchor 0.5
        yanchor 0.5
        text_size 40
        text_idle_color "#fff"
        text_hover_color "#aaa"
        action SetVariable("phone_number", phone_number + "8")

    textbutton "9":
        pos (1125, 810) 
        xanchor 0.5
        yanchor 0.5
        text_size 40
        text_idle_color "#fff"
        text_hover_color "#aaa"
        action SetVariable("phone_number", phone_number + "9")

    textbutton "C": 
        pos (795, 890) 
        xanchor 0.5
        yanchor 0.5
        text_size 40
        text_idle_color "#ff4444"
        text_hover_color "#ffaaaa"
        action [Play("sound", "sfx_no.mp3"), SetVariable("phone_number", "")]
    
    textbutton "0":
        pos (960, 890) 
        xanchor 0.5
        yanchor 0.5
        text_size 40
        text_idle_color "#fff"
        text_hover_color "#aaa"
        action SetVariable("phone_number", phone_number + "0")
    
    textbutton "Call":
        pos (1125, 890)
        xanchor 0.5
        yanchor 0.5
        text_size 40
        text_idle_color "#1eff00"
        text_hover_color "#99ff8f"
        action [Play("sound", "sfx_yes.mp3"), Return()]

screen spd_not_know_choice(prompt_text, action_var_name):
    frame:
        xalign 0.5
        yalign 0.5
        xysize (1305, 905)
        background Solid("#a0a0a0") 
        
        frame:
            xalign 0.5
            yalign 0.5
            xysize (1300, 900)
            background Solid("#050505") 
            padding (60, 40)

            vbox:
                xalign 0.5
                yalign 0.5
                spacing 20
                
                text prompt_text bold True size 45 color "#ffffff" xalign 0.5 text_align 0.5
                
                null height 50
                
                hbox:
                    xalign 0.5
                    spacing 200
                    
                    textbutton "Yes":
                        text_size 40 
                        text_color "#00ff08" 
                        text_hover_color "#ffffff"
                        text_bold True
                        action [Play("sound", "sfx_yes.mp3"), SetVariable(action_var_name, getattr(store, action_var_name) + 1), Return(True)]
                        
                    textbutton "No":
                        text_size 40 
                        text_color "#ff0000" 
                        text_hover_color "#ffffff"
                        text_bold True
                        action [Play("sound", "sfx_no.mp3"), Return(False)]



screen drag_hand:

    frame:
        xalign 0.5 yalign 0.5
        xysize (1305, 905)
        background Solid("#a0a0a0") 
        
        frame:
            xalign 0.5 yalign 0.5
            xysize (1300, 900)
            background Solid("#2f2f2f") 
            padding (60, 40)

            vbox:
                xalign 0.5 ypos 50
                spacing 10
                text "Concentrate your mind to do action." size 45 color "#ffffff" xalign 0.5
                text "[drag_count] / 3" size 30 color "#ff0000" xalign 0.5 bold True

            draggroup:
                xfill True
                yfill True

                
                drag:
                    drag_name "Reaching"
                    child Text("REACHING", size=40, color="#ffffff", bold=True, outlines=[(2, "#000")])
                    xpos 0.5 xanchor 0.5 ypos 0.35 yanchor 0.5
                    draggable False
                    droppable True

               
                drag:
                    drag_name "obj2"
                    child "hover grab" 
                    xpos 0.5 xanchor 0.5 ypos 0.85 yanchor 0.5
                    draggable True
                    dragged hand_dragged

label get_caught:
    if not persistent.get_caught:
        $ renpy.notify("Tip: Observe where she's looking before taking action.")
        $ persistent.get_caught = True
    show spd angry with dissolve
    spd "Hmm?"
    show spd idle with dissolve
    spd "What are you doing?"
    spd "Do you think we don't have a brain?"
    show me serious
    me "She caught me?!"
    show spd head_talk
    head "We actually don't have a brain!"
    spd "Oh!"
    show spd smirk
    spd "Anyway..."
    spd "I guess we have no choice."
    show spd idle
    spd "We have to get rid of you."
    me "'!?'"
    show spd laugh
    spd "We're just teasing you."
    show me smirk
    me "'Phew... I thought they were that cruel.'"
    show spd mauling with vpunch
    spd "We mean we have to kill you!"
    show spd head_talk
    head "Kill him, kill him!"
    show me scared
    me "'Please wake up... If this isn't a dream, then I'm really doomed-'"
    
    jump die

label check_clock_main_game2:
    scene bg sleep 2 with fade
    call screen main_game

screen table_clock3:
    add "bg clock" at fade_in_bg

    frame:
        background None
        align (0.5, 0.52)
        text "[hour:02d]:[minute:02d]" size 200 color "#00eea7"
    
    textbutton "Go back":
        xanchor 0.5
        yanchor 0.5
        xpos 0.7
        ypos 0.7
        action [Jump("check_clock_2")]
label check_clock_2:
    scene bg sleep 2
    call screen main_game

screen drag_:
    frame:
        xalign 0.5
        yalign 0.5
        xysize (1305, 905)
        background Solid("#a0a0a0") 
        
        frame:
            xalign 0.5
            yalign 0.5
            xysize (1300, 900)
            background Solid("#050505") 
            padding (60, 40)

            vbox:
                xalign 0.5
                ypos 50
                spacing 20
                
                text "Move your eyes to decide your fate." size 45 color "#ffffff" xalign 0.5 text_align 0.5

            draggroup:
                xfill True
                yfill True

                drag:
                    drag_name "Left"
                    child Text("LEFT", size=40, color="#ffffff", bold=True, outlines=[(2, "#000")])
                    xpos 0.2     
                    xanchor 0.5  
                    ypos 0.75
                    yanchor 0.5
                    draggable False
                    droppable True

                drag:
                    drag_name "Do nothing"
                    child Text("DO NOTHING", size=40, color="#ffffff", bold=True, outlines=[(2, "#000")])
                    xpos 0.5    
                    xanchor 0.5
                    ypos 0.75
                    yanchor 0.5
                    draggable False
                    droppable True

                drag:
                    drag_name "Right" 
                    child Text("RIGHT", size=40, color="#ffffff", bold=True, outlines=[(2, "#000")])
                    xpos 0.8    
                    xanchor 0.5
                    ypos 0.75
                    yanchor 0.5
                    draggable False
                    droppable True

                drag:
                    drag_name "obj1"
                    child "button_hover" 
                    xpos 0.5     
                    xanchor 0.5
                    ypos 0.35    
                    yanchor 0.5
                    draggable True
                    dragged eye_dragged

label label_spd_known:
    $ spd_known_clicked = True
    $ attempt += 1
    $ minute += 5
    show spd smirk with dissolve
    spd "We know you're in there."
    show spd think with dissolve
    spd "Really wonder how you got in this state."
    show spd idle with dissolve
    spd "Maybe we should do that~ What do you think?" 
    show spd head_talk
    head "Agree, agree!"
    show me anxiety
    me "'What should I do? I'm going to die!'"
    me "'I still have many things I want to do.'"
    me "..."
    show me idle
    me "Do I?"
    show spd joy1 with dissolve
    spd "We'll give you an option!"
    show spd head_talk
    head "Option, option!"
    show me stunned
    me "'Huh?'"
    me "'What does this mean?'"
    show spd idle with dissolve
    spd "We want to see what you can do."
    me "'Okay?'"
    show spd joy1 with dissolve
    spd "We will give you about 10 minutes."
    spd "We want to see  you struggle!"
    show spd head_talk
    head "Struggle, struggle!"
    show spd think
    spd "Or else.."
    show spd mauling with vpunch
    spd "Just let we eat You!"
    show spd smirk
    spd "If you want to live move your eyes to the left. But if you ready to end it's all you can move to the right."
    jump menu_third

label menu_third:
    call screen drag_eyes
    
    if _return == "Left":
        jump choices3_a
    elif _return == "Right":
        jump choices3_b
    elif _return == "Do nothing":
        jump choices3_c

label choices3_a:
    show me anxiety
    me "'I want to live... I can't back down yet.'"
    show spd consider with dissolve
    spd "Oh? I thought you'd be too scared to act."
    show spd head_talk
    head "Coward, coward!"
    show spd smirk
    spd "Good. Let's see what surprise you've got for me."
    $ spd_known_2 = True
    jump label_swift_work

label choices3_b:
    show me idle
    me "'I decide none of this is real.'"
    me "'I'll wake up after I die. Yes... that has to be it.'"
    show me talk
    me "'Besides...'"
    show me close_eyes
    me "'I'm tired... maybe this is just how it ends.'"
    show spd think with dissolve
    spd "Acceptance so soon? How boring."
    show spd joy1 with dissolve
    spd "But we won't complain about an easy meal."
    show spd joy2 with dissolve
    spd "Actually... let's give you one last chance to be interesting."
    show me stunned
    me "'Do I deserve this?'"
    me "'Maybe I shouldn't turn down her offer?'"
    jump label_spd_known2


label choices3_c:
    show me anxiety
    me "'I can't move... I can't even choose...'"
    show spd idle with dissolve
    spd "Still frozen? Time is ticking, little snack."
    show spd head_talk
    head "Tick tock, tick tock!"
    show spd mauling with vpunch
    spd "If you won't choose, we'll choose for you!"
    show spd smirk
    spd "Fine. Let see what you can do."
    jump label_swift_work

label label_swift_work:
    scene bg sleep 3 with dissolve
    show me anxiety
    me "'Even though I want to escape, I still don't know how.'"
    me "'Think [player_name] think!'"
    show me got_it
    me "'Oh!'"
    show me smirk
    me "'What if I cough as hard as hard as I can.'"
    me "'Maybe that could force myself to wake uo!'"
    show me accept
    me "'I'm a genuis!'"
    show me idle
    me "'But firstly, I need to {b}prepare{/b} what I want to do.' "
    me "'While avoid getting caught in the process.'"
    scene bg sleep 3 with fade
    call screen swift_work

label label_spd_known2:
    show spd joy2 with dissolve
    spd "First choice, we can pry into your {b}Dream{/b}."
    show me anxiety 1
    me "'Eh?'"
    show spd joy1 with dissolve
    spd "We just want you to guide us through it!"
    spd "It's really easy once we get in so don't worry."
    show spd joy2
    spd "We only ask for a small {b}reward{/b}."
    show spd idle
    spd "Second choice!"
    show spd angry
    spd "You just have to be.."
    show spd open_head with dissolve
    spd "Our food as you wish."
    show spd idle
    spd "What do you think?"
    show spd smirk
    spd "If you want to live move your eyes to the left. But if you ready to end it's all you can move to the right."
    show me anxiety
    me "'What should I do?'"
    jump menu_fourth

label menu_fourth:
    call screen drag_eyes
    
    if _return == "Left":
        jump choices4_a
    elif _return == "Right":
        jump choices4_b
    elif _return == "Do nothing":
        jump choices4_c

label choices4_a:
    show spd joy1
    spd "We know you're smart!"
    show spd joy2
    spd "Now close your eyes."
    show me anxiety
    me "'I hope this is the right choice...'"
    jump dream_session

label choices4_b:
    show spd smirk with dissolve
    spd "I guess we have no choice."
    show spd idle
    spd "Humen can be really stupid sometime..."
    show spd joy1
    spd "We like it though!"
    show spd joy2
    spd "Now close your eyes."
    show spd show_mouth with dissolve
    spd "..."
    show me scared
    me "*Gulp* 'I'll wake up next morning, right?"
    jump die

label choices4_c:
    show spd angry 
    spd "Hmph."
    spd "So you want to act like you can't choose."
    show spd laugh
    spd "Is't it funny? You can't decide even when death is knocking your door."
    show spd idle
    spd "Fine."
    show spd angry with dissolve
    pause 0.5
    show spd open_head with dissolve
    spd "We have no chice."
    play sound 'audio/sfx_js2.mp3'
    show spd mauling at zoomin50
    with vpunch
    spd "Die!!!"
    pause 1.0
    jump die

screen swift_work:
    add "bg sleep 3" at fade_in_bg

    imagebutton:
        xanchor 0.5
        yanchor 1.0
        pos (1831, 1055) 
        idle "idle sleep clock"
        hover "hover sleep clock"
        action [Hide("display_text"), Jump("swift_clock")]
        hovered Show("display_text", displayText="the clock")
        unhovered Hide("display_text")

    imagebutton:
        xanchor 0.5
        yanchor 1.0
        pos (206, 641) 
        idle "idle sleep window"
        hover "hover sleep window"
        action [Hide("display_text"), Jump("swift_window")]
        hovered Show("display_text", displayText="the window")
        unhovered Hide("display_text")

    imagebutton:
        xanchor 0.5
        yanchor 1.0
        pos (418, 1080) 
        idle "left arm"
        hover "hover grab"
        action [Hide("display_text"), Jump("swift_left_arm")]
        hovered Show("display_text", displayText="left arm")
        unhovered Hide("display_text")

    imagebutton:
        xanchor 0.5
        yanchor 1.0
        pos (1520, 1080) 
        idle "right arm"
        hover "hover grab"
        action [Hide("display_text"), Jump("swift_right_arm")]
        hovered Show("display_text", displayText="right arm")
        unhovered Hide("display_text")

    imagebutton:
        xanchor 0.5
        yanchor 1.0
        pos (1698, 940) 
        idle "idle sleep phone" 
        hover "hover sleep phone"
        action [Hide("display_text"), Jump("swift_phone")]
        hovered Show("display_text", displayText="the phone")
        unhovered Hide("display_text")

    imagebutton:
        at fade_in_bg
        xanchor 0.5
        yanchor 1.0
        pos (960, 1060) 
        idle "spd full lay"
        action [Hide("display_text"), Jump("swift_spd_menu")]
        hovered Show("display_text", displayText="Spd")
        unhovered Hide("display_text")

screen swift_confirm_choice(prompt_text, action_val):
    frame:
        xalign 0.5
        yalign 0.5
        xysize (1305, 905)
        background Solid("#a0a0a0") 
        
        frame:
            xalign 0.5
            yalign 0.5
            xysize (1300, 900)
            background Solid("#050505") 
            padding (60, 40)

            vbox:
                xalign 0.5
                yalign 0.5
                spacing 20
                
                text prompt_text bold True size 45 color "#ffffff" xalign 0.5 text_align 0.5
                
                null height 50
                
                hbox:
                    xalign 0.5
                    spacing 200
                    
                    textbutton "Yes":
                        text_size 40 
                        text_color "#00ff08" 
                        text_hover_color "#ffffff"
                        text_bold True
                        action [Play("sound", "sfx_yes.mp3"), SetVariable("swift_chosen_action", action_val), Return(True)]
                        
                    textbutton "No":
                        text_size 40 
                        text_color "#ff0000" 
                        text_hover_color "#ffffff"
                        text_bold True
                        action [Play("sound", "sfx_no.mp3"), Return(False)]


label swift_clock:
    if look_left:
        jump get_caught
        
    call screen swift_confirm_choice("Do you want to choose the clock?\nYou can only pick one action.", "clock")
    if _return:
        me "'I'll keep the clock in mind.'"
    
    call screen swift_work

label swift_window:
    if look_right:
        jump get_caught
        
    call screen swift_confirm_choice("Do you want to choose the window?\nYou can only pick one action.", "window")
    if _return:
        me "'I'll aim for the window.'"
        
    call screen swift_work

label swift_left_arm:
    if look_center:
        jump get_caught
        
    call screen swift_confirm_choice("Do you want to choose your left arm?\nYou can only pick one action.", "left_arm")
    if _return:
        me "'I'll ready my left arm.'"
        
    call screen swift_work

label swift_right_arm:
    if look_center:
        jump get_caught
        
    call screen swift_confirm_choice("Do you want to choose your right arm?\nYou can only pick one action.", "right_arm")
    if _return:
        me "'I'll ready my right arm.'"
        
    call screen swift_work

label swift_phone:
    if look_left:
        jump get_caught
        
    call screen swift_confirm_choice("Do you want to choose the phone?\nYou can only pick one action.", "phone")
    if _return:
        me "'I'll prepare to grab the phone.'"
        
    call screen swift_work

screen drag_eyes:
    frame:
        xalign 0.5
        yalign 0.5
        xysize (1305, 905)
        background Solid("#a0a0a0") 
        
        frame:
            xalign 0.5
            yalign 0.5
            xysize (1300, 900)
            background Solid("#000000") 
            padding (60, 40)

            vbox:
                xalign 0.5
                ypos 50
                spacing 20
                text "Move your eyes to decide your fate." size 45 color "#ff0000" xalign 0.5 text_align 0.5

            draggroup:
                xfill True
                yfill True
                
                if not swift_chosen_action == None:
                    drag:
                        drag_name "Take action"
                        child Text("TAKE ACTION", size=40, color="#ffffff", bold=True, outlines=[(2, "#000")])
                        xpos 0.5 
                        xanchor 0.5
                        ypos 0.35 
                        yanchor 0.5
                        draggable False
                        droppable True
                
                drag:
                    drag_name "Left"
                    child Text("Left", size=40, color="#ffffff", bold=True, outlines=[(2, "#000")])
                    xpos 0.2     
                    xanchor 0.5  
                    ypos 0.55
                    yanchor 0.5
                    draggable False
                    droppable True


                drag:
                    drag_name "Do nothing"
                    child Text("DO NOTHING", size=40, color="#ffffff", bold=True, outlines=[(2, "#000")])
                    xpos 0.5 
                    xanchor 0.5
                    ypos 0.75
                    yanchor 0.5
                    draggable False
                    droppable True

                drag:
                    drag_name "Right" 
                    child Text("RIGHT", size=40, color="#ffffff", bold=True, outlines=[(2, "#000")])
                    xpos 0.8 
                    xanchor 0.5
                    ypos 0.55
                    yanchor 0.5
                    draggable False
                    droppable True

                drag:
                    drag_name "obj1"
                    child "button_hover" 
                    xpos 0.5 
                    xanchor 0.5
                    ypos 0.55
                    yanchor 0.5
                    draggable True
                    dragged eye_dragged

screen drag_eyes2:
    frame:
        xalign 0.5
        yalign 0.5
        xysize (1305, 905)
        background Solid("#a0a0a0") 
        
        frame:
            xalign 0.5
            yalign 0.5
            xysize (1300, 900)
            background Solid("#000000") 
            padding (60, 40)

            vbox:
                xalign 0.5
                ypos 50
                spacing 20
                text "Move your eyes to decide your fate." size 45 color "#ff0000" xalign 0.5 text_align 0.5

            draggroup:
                xfill True
                yfill True
                
                if not swift_chosen_action == None:
                    drag:
                        drag_name "Take action"
                        child Text("TAKE ACTION", size=40, color="#ffffff", bold=True, outlines=[(2, "#000")])
                        xpos 0.5 
                        xanchor 0.5
                        ypos 0.35 
                        yanchor 0.5
                        draggable False
                        droppable True
                
                drag:
                    drag_name "Left"
                    child Text("GO BACK", size=40, color="#a0a0a0", bold=True, outlines=[(2, "#000")])
                    xpos 0.2     
                    xanchor 0.5  
                    ypos 0.55
                    yanchor 0.5
                    draggable False
                    droppable True


                drag:
                    drag_name "Do nothing"
                    child Text("DO NOTHING", size=40, color="#ffffff", bold=True, outlines=[(2, "#000")])
                    xpos 0.5 
                    xanchor 0.5
                    ypos 0.75
                    yanchor 0.5
                    draggable False
                    droppable True

                drag:
                    drag_name "Right" 
                    child Text("RIGHT", size=40, color="#ffffff", bold=True, outlines=[(2, "#000")])
                    xpos 0.8 
                    xanchor 0.5
                    ypos 0.55
                    yanchor 0.5
                    draggable False
                    droppable True

                drag:
                    drag_name "obj1"
                    child "button_hover" 
                    xpos 0.5 
                    xanchor 0.5
                    ypos 0.55
                    yanchor 0.5
                    draggable True
                    dragged eye_dragged

label swift_spd_menu:
    call screen drag_eyes2
    
    $ choice = _return
    

    if choice == "Left":
        call screen swift_work

    if choice == "Right":
        show spd smirk with dissolve
        spd "Giving up so easily? That makes things simple."
        show spd open_head with dissolve
        spd "Time to eat."
        jump die

    elif choice == "Take action":
        scene bg sleep 3 with fade
        show spd idle
        show me anxiety
        me "'Okay, I have to do it now!'"
        show spd shock
        show me serious
        play sound "audio/sfx_cough.mp3"
        me "*Cough!!* Augh- Haa."
        show me anxiety
        me "'Augh- Might be a little bit stiff but I can move now!'"
        show spd angry with dissolve
        spd "What're you doing."
        stop music
        

        if swift_chosen_action == "clock":
            jump ending_clock
        elif swift_chosen_action == "window":
            jump ending_window
        elif swift_chosen_action == "left_arm":
            jump ending_left
        elif swift_chosen_action == "right_arm":
            jump ending_left_right
        elif swift_chosen_action == "phone":
            jump ending_phone


    elif choice == "Do nothing":
        scene black with dissolve
        pause 2.0
        "{i}10 minutes later..."
        scene bg sleep 3 with dissolve
        show spd joy1 with dissolve
        spd "Time's up!"
        show spd shh with dissolve
        spd "What's your plan? Show it to us now!"
        spd "..."
        show spd joy1
        spd "Hello? Anything?"
        show me anxiety
        me "'I don't know what to do...'"
        show me side_eyes
        me "'Maybe I should just pretend I'm still sleeping.'"
        me "'I hope she doesn't notice.'"
        
        if spd_known_2:
            pause 1.0
            show spd angry with dissolve
            spd "That's it?"
            spd "I thought you'd be cleverer than this."
            show spd idle
            spd "But you're choosing to act like a complete moron."
            show spd think
            spd "Don't you agree?"
            show spd head_talk
            head "Agree! Totally agree!"
            show spd angry
            spd "..."

            scene bg look 1 with fade
            pause 1.0
            spd "Still quiet?" 
            pause 1.0
            spd "You really believe we didn't notice?"
            show me scared
            me "'She shoundn't know right?'"
            scene bg look with dissolve

            spd "What an arrogant piece of garbage."
            head "Garbage, garbage!"
            spd "Then you're of no use to us."
            jump die
        else:
            show spd think with dissolve
            spd "I guess that first cough was just a coincidence."
            show spd sigh with dissolve
            spd "*Sigh* What a waste of time."
            $ spd_known = False
            $ spd_known_clicked  = False
            $ attempt = 2
            $ minute += 5
            $ swift_chosen_action = None

            call screen main_game

#ending with one action
label ending_clock:
    "You reach out to {i}the clock{/i}."
    show spd consider
    spd "So... what exactly are you doing?"
    show me anxiety
    me "'What am I doing? I don't even know myself!'"
    
    show spd smirk
    spd "Don't tell me you did all that without thinking at all?"
    me "'Damn it, she's reading my mind...'"
    
    show spd sigh with dissolve
    spd "Hey hey. We don't have all day, you know? If you're just going to stand there, get out!"
    show me angry
    me "'This isn't even your house. Why are you acting like the boss?'"
    show me well
    me "'Besides, don't act like you'd actually let me leave.'"
    
    show spd joy1
    spd "But don't think you're getting out of here without a scratch."
    me "'Called it.'"
    show me talk
    me "I..."
    
    show spd think
    spd "You?"
    show spd head_talk
    spd "We?"
    show spd think
    spd "We? No, I talk about the mortal!"
    
    show spd idle
    me "I... want to throw away this clock."
    show spd consider
    spd "Okay?"
    show me idle
    me "Because I want to see time...fly?"
    spd "..."
    me "..."
    spd "..."
    spd "Pfft."
    show me what
    me "'Pfft?'"
    
    show spd laugh
    spd "FUHAHAHAHA!"
    spd "Oh, I'm tearing up! What was that!?"
    spd "That was so stupid, haha!"
    show me well
    me "'Now I just feel embarrassed...'"
    
    show spd laugh1
    spd "I guess you truly don't have a brain."
    spd "Should we worry about what to eat, there might be nothing in the skull? Haha! "
    show me smirk
    me "Does that mean... I can go now?"
    
    show spd angry
    spd "Nah. You're not going anywhere."
    
    show spd think
    spd "But we should 'eat' in another way instead, don't you think?"
    show me talk
    me "I-"
    show spd head_talk
    head "Think so! Think so!"
    show me well

    me "'What about my opinion...?'"
    show me sigh
    me "*Sigh* I guess I have no time left."
    
    show spd idle
    spd "You still have plenty of time left with me. Don't be so pessimistic."
    
    show spd mauling with dissolve
    spd "Now... close your eyes."
    jump dream_session
    return

label ending_window:
    "You looked toward {i}the window{/i}."
    show me serious
    me "'I need to move fast!'"
    show spd angry 
    show me shock
    me "What-?!"
    me "'I can't move my body!'"
    play sound 'audio/sfx_am2.mp3' volume 0.05
    scene spd catch 1 with dissolve
    spd "What do you think you're doing?"
    show me anxiety
    me "I- I was just-"
    spd "Tell me, do you still think you can rebel against us?"
    
    scene spd catch 2 with dissolve
    show me blank
    me "I-"
    
    menu menu_get_caught:
        "Wriggle":
            spd "Still haven't learned your lesson?"
            spd "I never mentioned it, but we have a very short temper."
            me "Please wait-"
            spd "So... just die."
            jump die2

        "Give up":
            scene bg sleep 3 with fade 
            show spd angry
            spd "Since this is your first time, I'll let you off the hook."
            show spd shh
            spd "But don't try any more stupid stunts. I can't promise I'll be this kind next time."

            jump dream_session

label ending_left:
    if knife_recieved:
        jump ending_left_knife
    else:
        jump ending_left_right



label ending_left_knife:
    play sound 'audio/sfx_knife.mp3'
    "You pick up {i}the knife {/i}."
    show me serious
    me "Haa-!" 
    show knife with dissolve
    "You plunged the knife with all your might into its chest."
    play sound 'audio/sfx_js2.mp3'
    show bg red
    pause 0.1
    show black 
    pause 0.1
    scene bg sleep 3
    show spd stabbed1 at zoomout300
    with vpunch
    pause 0.1
    show blood1 black at zoomin200
    pause 0.1
    show blood2 black at zoomin100
    pause 1.0 
    hide blood1 with dissolve
    hide blood2 with dissolve
    pause 1.0
    show spd stabbed2
    show me anxiety
    me "Is... is it working?"
    "You see the creature stand there silently."
    "Black liquid keep gushing out before your eyes."
    spd "..."
    show me smirk
    me "Hah! I did it!"
    me "That was easier than I thought."
    show me idle
    me "What should I do next."
    show me talk
    me "I've never thought this far."
    pause 1.0
    show me shock
    me "Wait... why can't I pull my arm out?"
    show me serious
    me "'Because I was thinking for too long, I've noticed my arm has been devoured up to the elbow.'"
    spd "Fufufu~ Good, good~"
    spd "I wanted to see what you were capable of, and this is your answer?"
    spd "I never expected you to smuggle a knife in here."
    spd "I suppose I was too reckless."
    
    me "'This is bad. It's stuck!'"
    
    scene spd grabbed 1 at lower  
    with fade
    pause 2.0
    scene spd grabbed at lower  
    with dissolve
    play sound 'audio/sfx_am2.mp3' volume 0.5
    play music 'audio/music_ending.mp3' volume 0.5
    "Despite your effort, your hand is unable to move."
    "The liquid stuck into your hand and keep pulling you in like it has life of it own."
    spd "I'm sorry for making us experience this pain."
    head "Pain! Pain!"
    
    spd "Alright... I'll leave the rest to you now."
    scene spd grabbed  at movetoupper
    show me blank
    me "Wait! We can talk about this!"
    head "Revenge! Revenge!"
    me "Wait-!"
    scene black
    pause 0.1
    play sound 'audio/sfx_crack.mp3' 
    scene spd grabbed bite at upper
    with hpunch
    pause 1.0
    scene black with fade
    " "
    "You were devoured by the monster's {b}mouth{/b}."
    
    scene bg gross
    "For some reason, your consciousness doesn't fade right away. You feel every wet, slimy texture of the inner walls."
    "You can't move. You can't see. You can only feel."
    "Is this a fate worse than death?"
    scene bg ending 3 with fade
    play music "audio/music_ending.mp3" volume 0.5
    pause 2.0
    $ persistent.ending3 = True
    "Ending 3 - {b}Bite the Dust{/b}"
    "You realise that the mouth isn't just an accessory."
    return


label ending_left_right:
    "You moved your {i}arm{/i}."
    show me serious
    me "Ha!"
    show spd shock
    spd "Eh!?"
    
    show spd embarrassed with dissolve
    spd "Where do you think you're touching, you pervert?!"
    show spd embarrassed head
    head "Pervert! Pervert!"
    show me smirk
    me "I-I didn't mean to!"
    show spd shy with dissolve
    show me anxiety
    me "'This is the worst possible timing!'"
    show me got_it
    me "'Wait... isn't this my chance to run?!'"

    menu menu_touch:
        "Run away":
            show spd angry
            spd "Where do you think you're going?"
            play sound 'audio/sfx_caught.mp3' volume 0.5
            scene spd catch 1 with fade
            show me blank
            me "Augh- I- I'm sorry!"
            spd "So, you don't want to take responsibility for your hands?"
            
            scene spd catch 2 with dissolve
            me "I-"
            spd "Is this what humans call 'being taken advantage of'?"
            spd "I've lost my appetite now."
            spd "Just die already."
            jump die2

        "Apologize":
            show me sigh
            me "I'm so sorry! It was an accident!"
            show spd angry
            spd "..."
            show spd sigh
            spd "Fine... I'll pretend that didn't happen."
            show me talk
            me "Does that mean I can leave?"
            
            show spd smirk
            spd "Nope."
            show spd think
            spd "But I have another idea."
            show me anxiety
            me "'I have a really bad feeling about this...'"
            show spd consider
            spd "But since we're kind, we decide to use you in somthing much more interesting."
            show me smirk
            me "What are talking about?"
            show spd shh
            head "Just watch and close your eyes."
            me "How can I watch with my eyes close..."
            jump dream_session
    

label ending_phone:
    "You reached for your {i}phone{/i}."
    show me smirk
    me "Got it!"
    show me serious
    me "Ah-"
    
    show spd with_phone1 with dissolve
    spd "What's this, hmm?~"
    show me smirk
    me "Ahem... Ma'am, could you please give that back to me?"
    
    show spd with_phone2
    spd "And what if I don't?"
    show me stunned
    me "..."
    spd "Relax, I was just messing with you."
    spd "We already know what this is."
    
    scene spd swallow1 with dissolve
    pause 1.0
    scene spd swallow2 with dissolve
    pause 1.0
    scene black
    pause 0.1
    play sound 'audio/sfx_crack.mp3'
    scene spd swallow3
    pause 1.0

    spd "Tastes like metal."
    
    scene bg sleep 3 with dissolve
    show spd idle
    spd "Don't do anything stupid again."
    show me anxiety
    me "..."
    
    show spd smirk
    spd "This is your first and last warning."
    show spd idle
    spd "Now that the appetizer is gone, it's time for the main course."
    show me stunned
    me "?!"
    
    show spd joy2
    spd "It's not what you think... though you'll find out soon enough."
    show spd shh
    spd "Now stay still and be a good boy."
    jump dream_session



label label_spd_notknown:
    $ spd_notknown_clicked = True
    
    show spd idle with dissolve
    spd "We need to prepare before we can do \"that\" thing."
    show spd think with dissolve
    spd "Are you ready?"
    show spd head_talk
    head "Ready!"
    show spd joy1 with dissolve
    spd "Then it'll be time for main dish!" 
    scene bg sleep 3 with dissolve
    call screen main_game

label die:
    stop music
    $ attempt_enable = False
    window hide
    play sound 'audio/sfx_js.mp3'
    show spd jump_scare at zoomin100
    with vpunch
    pause 0.1
    show blood1 at zoomin200
    pause 0.1
    show blood2 at zoomin100
    pause 1.0
    scene black with fade
    pause 0.5
    play music "audio/music_ending.mp3" volume 0.5
    scene bg ending 1 with fade
    pause 2.0
    $ persistent.ending1 = True
    "Ending 1 - {b}Classic Death{/b}"
    "You died."
    "This is not a dream."
    
    pause 2.0
    return


label die2:
    stop music
    scene black
    pause 0.1
    play sound 'audio/sfx_crack.mp3'
    scene spd catch 3
    "{i}*CRACK*"

    scene black with fade
    pause 0.5
    scene bg ending 2 with fade
    play music "audio/music_ending.mp3" volume 0.5
    pause 2.0

    "Ending 2 - {b}Twisted Death{/b}"
    $ persistent.ending2 = True
    "You died."
    "But with some \"twist\"."
    
    
    return


label dream_session:
    
    scene bg blink1 with fade
    pause 1.0
    scene bg blink2 with wipedown
    pause 1.0
    scene bg blink3 with wipedown
    pause 1.0
    scene black with dissolve
    pause 1.0
    play music 'audio/music_confuse2.mp3' volume 0.3 fadein 3
    scene bg dream bedroom with fade
    pause 0.5
    show me anxiety
    me "What- what just happened?"
    "This is the end of part one."
    "Next part will focus more on story, horror aspects, and most importantly- Dating!"
    "Thank for playing."

    return
